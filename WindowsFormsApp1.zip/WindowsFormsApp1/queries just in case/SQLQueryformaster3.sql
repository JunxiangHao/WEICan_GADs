﻿--create view v1 as
--select  sum((isnull(PDTH,0) - (isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/isnull(PDTH,0))/count(ReptMonth) as TechnoCenter
--from TechnoCenter_Performance

--select  sum((isnull(PDTH,0) - (isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/isnull(PDTH,0))/count(ReptMonth) as WEICan
--from Performance
select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS TechnoCenter_Availablity
from TechnoCenter_Performance

select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS WEICan_Availablity
from Performance

select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(isnull(TotInstCapacity,0)/isnull(TurbineCount,0)) from TechnoCenter_SubGroup)) as TechnoCenter_capacity
FROM TechnoCenter_Performance

select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(SystemMW) from TechnoCenter_SubGroup)) as WEICan_capacity
FROM Performance

