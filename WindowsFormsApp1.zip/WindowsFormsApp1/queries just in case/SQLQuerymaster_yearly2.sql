﻿--CREATE VIEW master_Summary_Turbine_Avg_Yearly2 AS 
--select * , CONVERT(DECIMAL(10,2),TotalHrs/(select sum(TotalHrs) from master_Summary_Turbine_Avg_Yearly_1 group by ())) as PercentHrs, 
--CONVERT(DECIMAL(10,2),TotalCount/(select sum(TotalCount) from master_Summary_Turbine_Avg_Yearly_1 group by ())) as PercentCount 
--from master_Summary_Turbine_Avg_Yearly_1
CREATE VIEW master_Summary_Turbine_Avg_Yearly2 AS 
select * , CONVERT(DECIMAL(10,2),TotalHrs/(select sum(TotalHrs) from master_Summary_Turbine_Avg_Yearly_1 group by ())) as PercentHrs, 
CONVERT(DECIMAL(10,2),TotalCount/(select sum(TotalCount) from master_Summary_Turbine_Avg_Yearly_1 group by ())) as PercentCount 
from master_Summary_Turbine_Avg_Yearly_1
