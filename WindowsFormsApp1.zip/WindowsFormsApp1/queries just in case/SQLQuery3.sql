﻿CREATE VIEW Summary_MW_Category_Month as 
SELECT a.SubGroupID as SubGroupID, a.System as System, sum(FTH)*count(TurbineCount)/sum(TurbineCount) as FTH, sum(ForcedCount)*count(TurbineCount)/sum(TurbineCount) as ForcedCount, sum(MTH)*count(TurbineCount)/sum(TurbineCount) as MTH, sum(MaintCount)*count(TurbineCount)/sum(TurbineCount) as  MaintCount, sum(PTH)*count(TurbineCount)/sum(TurbineCount) as PTH, sum(PlannedCount)*count(TurbineCount)/sum(TurbineCount) as PlannedCount 
FROM SuperOutages a
left join SubGroup b
on a.SubGroupID = b.SubGroupID
GROUP BY a.System, a.SubGroupID 

