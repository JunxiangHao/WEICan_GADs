﻿ISNULL(Avg_MTH,0) FROM Summary_MW_Avg_Yealy1
--select *, (Avg_MTH+1) as TotalHrs, (ForcedCount+MaintCount+PlannedCount) as TotalCount
--from Summary_MW_Avg_Yealy1