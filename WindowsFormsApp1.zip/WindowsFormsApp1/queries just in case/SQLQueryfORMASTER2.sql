﻿--select * from a1,a2
--string field = d.Rows[0].Field<string>(3);
--string abc= dt.Rows[0]["column name"].ToString();
--foreach(DataRow row in dt.Rows)
--{  string value = row[3].ToString(); }
--USE StoreDB;
SELECT name FROM sys.Tables where name like '%_Outages';