﻿ string subQuer1 = "CREATE VIEW master_Summary_MW_Avg_Yearly_N AS select WEICan.System , CONVERT(DECIMAL(10,2),(isnull(WEICan.FTH,0)";
                string subQuer2 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";
                string subQuer3 = ",CONVERT(DECIMAL(10,2),(isnull(WEICan.ForcedCount*1.0,0)";
                string subQuer4 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";

                string subQuer5 = ", CONVERT(DECIMAL(10,2),(isnull(WEICan.MTH,0)";
                string subQuer6 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";
                string subQuer7 = ",CONVERT(DECIMAL(10,2),(isnull(WEICan.MaintCount*1.0,0)";
                string subQuer8 = "((select sum(TurbineCount) from WEICan_SubGroup)";

                string subQuer9 = ", CONVERT(DECIMAL(10,2),(isnull(WEICan.PTH,0)";
                string subQuer10 = "((select sum(TurbineCount) from WEICan_SubGroup)";
                string subQuer11 = ",CONVERT(DECIMAL(10,2),(isnull(WEICan.PlannedCount*1.0,0)";
                string subQuer12 = "((select sum(TurbineCount) from WEICan_SubGroup)";

                //string subQuer13 = ", CONVERT(DECIMAL(10,5),(isnull(WEICan.FTH,0)";

                string subQuer20 = "from WEICan_Wind_Farm_Summary_Category WEICan  ";

                foreach (String Name in listp)
                {
                    if (Name != "WEICan")
                    {
                        subQuer1 += "+isnull(" + Name + ".FTH,0)";
                        subQuer2 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer3 += "+isnull(" + Name + ".ForcedCount*1.0,0)";
                        subQuer4 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";

                        subQuer5 += "+isnull(" + Name + ".MTH,0)";
                        subQuer6 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer7 += "+isnull(" + Name + ".MaintCount*1.0,0)";
                        subQuer8 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";

                        subQuer9 += "+isnull(" + Name + ".PTH,0)";
                        subQuer10 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer11 += "+isnull(" + Name + ".PlannedCount*1.0,0)";
                        subQuer12 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";

                        

                        subQuer20 += "full join " + Name + "_Wind_Farm_Summary_Category " + Name + " " +
                            "on WEICan.System = " + Name + ".System ";
                        
                    }
                }
                subQuer1 +=   ")/";
                subQuer2 +=  ")) as FTH ";
                subQuer3 +=  ")/";
                subQuer4 += ")) as ForcedCount ";

                subQuer5 += ")/";
                subQuer6 +=  ")) as MTH ";
                subQuer7 +=  ")/";
                subQuer8 += ")) as MaintCount ";

                subQuer9 +=  ")/";
                subQuer10 += ")) as PTH ";
                subQuer11 +=  ")/";
                subQuer12 +=  ")) as PlannedCount ";

                string subQuer21 = subQuer1 + subQuer2 + subQuer3 + subQuer4 + subQuer5 + subQuer6 + subQuer7 + subQuer8 + subQuer9 + subQuer10 + subQuer11 + subQuer12 + subQuer20;
               // MessageBox.Show("query: " + subQuer21);
                SqlCommand cm0 = new SqlCommand(subQuer21, con);
                cm0.ExecuteNonQuery();

                SqlCommand cm = new SqlCommand("CREATE VIEW master_Summary_MW_Avg_Yearly2 AS " +
                    "select System, FTH, ForcedCount, MTH, MaintCount, PTH, PlannedCount, " +
                    "(FTH+MTH+PTH) AS TotalHrs, (ForcedCount+MaintCount+PlannedCount) AS TotalCount, " +
                    "CONVERT(DECIMAL(10,2),(FTH+MTH+PTH)/(select sum(FTH+MTH+PTH) from master_Summary_Turbine_Avg_Yearly_N group by ())) as PercentHrs, " +
                    "CONVERT(DECIMAL(10,2),(ForcedCount+MaintCount+PlannedCount)/(select sum(ForcedCount+MaintCount+PlannedCount) from master_Summary_Turbine_Avg_Yearly_N group by ())) as PercentCount " +
                    "FROM master_Summary_Turbine_Avg_Yearly_N", con);
                cm.ExecuteNonQuery();


                SqlCommand cm2 = new SqlCommand("CREATE VIEW master_Summary_Turbine_Avg_Monthly AS " +
                    "select System, " +
                    "CONVERT(DECIMAL(10,2),FTH/12) as FTH, " +
                    "CONVERT(DECIMAL(10,2),ForcedCount/12) as ForcedCount, " +
                    "CONVERT(DECIMAL(10,2),MTH/12) as MTH, " +
                    "CONVERT(DECIMAL(10,2),MaintCount/12) as MaintCount, " +
                    "CONVERT(DECIMAL(10,2),PTH/12) as PTH, " +
                    "CONVERT(DECIMAL(10,2),PlannedCount/12) as PlannedCount, " +
                    "CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs, " +
                    "CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount, PercentHrs,PercentCount " +
                    "from master_Summary_Turbine_Avg_Yearly2", con);
                cm2.ExecuteNonQuery();