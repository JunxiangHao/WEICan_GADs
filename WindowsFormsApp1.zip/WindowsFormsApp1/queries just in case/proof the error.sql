﻿SELECT sum(FTH) as FTH from TechnoCenter_Summary_perTurbine_Category_Month where System = 'Electrical' and ReptMonth =2
--SELECT TABLE_NAME
--FROM dbo.TABLES
--WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG='dbName'