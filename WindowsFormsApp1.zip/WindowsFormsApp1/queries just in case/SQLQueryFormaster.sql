﻿--select  sum((isnull(PDTH,0) - (isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/PDTH)/count(ReptMonth) as REAF
--from TechnoCenter_Performance

select sum(NAG)/(sum(PDTH) * (select sum(TotInstCapacity) from TechnoCenter_SubGroup)) as RNCF
FROM TechnoCenter_Performance
