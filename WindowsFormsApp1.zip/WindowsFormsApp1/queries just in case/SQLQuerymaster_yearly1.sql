﻿CREATE VIEW master_Summary_Turbine_Avg_Yearly_1 AS 
select b.System, 
CONVERT(DECIMAL(10,2),(isnull(a.FTH,0)+isnull(b.FTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as FTH, 
CONVERT(DECIMAL(10,2),(isnull(a.ForcedCount*1.0,0)+isnull(b.ForcedCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as ForcedCount, 
CONVERT(DECIMAL(10,2),(isnull(a.MTH,0)+isnull(b.MTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as MTH, 
CONVERT(DECIMAL(10,2),(isnull(a.MaintCount*1.0,0)+isnull(b.MaintCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as MaintCount, 
CONVERT(DECIMAL(10,2),(isnull(a.PTH,0)+isnull(b.PTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as PTH, 
CONVERT(DECIMAL(10,2),(isnull(a.PlannedCount*1.0,0)+isnull(b.PlannedCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as PlannedCount, 
CONVERT(DECIMAL(10,5),(isnull(a.FTH,0)+isnull(b.FTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))+(isnull(a.MTH,0)+isnull(b.MTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))+(isnull(a.PTH,0)+isnull(b.PTH,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) as TotalHrs, 
CONVERT(DECIMAL(10,5),(isnull(a.ForcedCount*1.0,0)+isnull(b.ForcedCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))+(isnull(a.MaintCount*1.0,0)+isnull(b.MaintCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))+(isnull(a.PlannedCount*1.0,0)+isnull(b.PlannedCount*1.0,0))/((select sum(TurbineCount) from TechnoCenter_SubGroup)+(select sum(TurbineCount) from WEICan_SubGroup))) TotalCount 
from TechnoCenter_Wind_Farm_Summary_Category a
full join WEICan_Wind_Farm_Summary_Category b
on a.System = b.System