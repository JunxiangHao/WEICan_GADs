﻿--CREATE VIEW WEICan_GAG2 AS select sum(GAG) AS Site1 from WEICan_Performance 
--CREATE VIEW TechnoCenter_GAG2 as select sum(b.GAG) AS Site2 from TechnoCenter_Performance b
--select a.Site1/(select sum(TotInstCapacity) from WEICan_SubGroup) as Site, 
--(a.Site1+b.Site2)/((select sum(TotInstCapacity) from WEICan_SubGroup)+(select sum(TotInstCapacity) from TechnoCenter_SubGroup)) as Average 
--from WEICan_GAG2 a, TechnoCenter_GAG2 b
---select  (a.Site1+b.Site2)/((select sum(TotInstCapacity) from WEICan_SubGroup)+(select sum(TotInstCapacity) from TechnoCenter_SubGroup)) as Average from WEICan_GAG2 a, TechnoCenter_GAG2 b

--CREATE VIEW WEICan_EUTH as select sum(TotalHrs) as Site from WEICan_Summary_perMW_Avg_Yearly_1
--CREATE VIEW All_EUTH as select sum(TotalHrs) as average from master_Summary_MW_Avg_Yearly_1
--select Site, average from WEICan_EUTH, All_EUTH
--CREATE VIEW WEICan_PDTH AS select sum(PDTH) AS Site from WEICan_Performance 
--CREATE VIEW TechnoCenter_PDTH as select sum(PDTH) AS Site from TechnoCenter_Performance 
--CREATE VIEW WEICan_RUTH AS select sum(RUTH) AS Site from WEICan_Performance 
--CREATE VIEW TechnoCenter_RUTH as select sum(RUTH) AS Site from TechnoCenter_Performance 
select (PDTH-RUTH) as SATH 