﻿--select (WEICan_NAG.Site / WEICan_PDTH.Site*(select sum(turbineCount)/count(turbineCount) from WEICan_SubGroup) + TechnoCenter_NAG.Site/TechnoCenter_PDTH.Site*(select sum(turbineCount)/count(turbineCount) from TechnoCenter_SubGroup))/((select sum(TotInstCapacity)/count(TotInstCapacity) from WEICan_SubGroup)+(select sum(TotInstCapacity)/count(TotInstCapacity) from TechnoCenter_SubGroup)) from WEICan_NAG, WEICan_PDTH, TechnoCenter_NAG, TechnoCenter_PDTH
--CREATE VIEW WEICan_NAG AS select sum(NAG) AS Site from WEICan_Performance
--CREATE VIEW WEICan_PDTH AS select sum(PDTH) AS Site from WEICan_Performance
--CREATE VIEW TechnoCenter_NAG AS select sum(NAG) AS Site from TechnoCenter_Performance
--CREATE VIEW TechnoCenter_PDTH AS select sum(PDTH) AS Site from TechnoCenter_Performance
select (WEICan_NAG.Site / WEICan_PDTH.Site * (select sum(turbineCount)/count(turbineCount) from WEICan_SubGroup) 
+ TechnoCenter_NAG.Site/TechnoCenter_PDTH.Site*(select sum(turbineCount)/count(turbineCount) from TechnoCenter_SubGroup)
)/(
(select sum(TotInstCapacity)/count(TotInstCapacity) from WEICan_SubGroup)
+(select sum(TotInstCapacity)/count(TotInstCapacity) from TechnoCenter_SubGroup)
) from WEICan_NAG, WEICan_PDTH, TechnoCenter_NAG, TechnoCenter_PDTH
