﻿--CREATE VIEW a1 AS 
--select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS TechnoCenter_Availablity
--from TechnoCenter_Performance

--CREATE VIEW a2 AS 
--select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS WEICan_Availablity
--from Performance

--CREATE VIEW TechnoCenter_capacity AS 
--select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(isnull(TotInstCapacity,0)/isnull(TurbineCount,0)) from TechnoCenter_SubGroup)) as TechnoCenter_capacity
--FROM TechnoCenter_Performance

--CREATE VIEW WEICan_capacity AS
--select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(SystemMW) from TechnoCenter_SubGroup)) as WEICan_capacity
--FROM Performance
--CREATE VIEW a4 AS select Field from a3 UNPIVOT (Field for ColumnName IN ([TechnoCenter_Availablity],[WEICan_Availablity])) unpvt

select Field , (select avg(Field) from a4) as Average from a4
--CREATE VIEW a3 AS select * from a1,a2
