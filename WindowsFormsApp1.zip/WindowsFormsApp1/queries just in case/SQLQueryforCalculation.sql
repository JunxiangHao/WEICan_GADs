﻿
select SysCompCode, sum(FTH) as FTH, sum(ForcedCount) as ForcedCount, sum(MTH) as MTH, sum(MaintCount) as  MaintCount, sum(PTH) as PTH, sum(PlannedCount) as PlannedCount
from Outages
GROUP BY SysCompCode

select b.System, sum(FTH) as FTH, sum(ForcedCount) as ForcedCount, sum(MTH) as MTH, sum(MaintCount) as  MaintCount, sum(PTH) as PTH, sum(PlannedCount) as PlannedCount
from Outages a 
inner join [Sys-Com Codes] b
on a.SysCompCode = b.Entry
group by b.System


select SysCompCode,FTH/TotInstCapacity as FTH, ForcedCount/TotInstCapacity as ForcedCount, MTH/TotInstCapacity as MTH, MaintCount/TotInstCapacity as  MaintCount, PTH/TotInstCapacity as PTH, PlannedCount/TotInstCapacity as PlannedCount
from Outages a
left join SubGroup b
on a.PK = b.PK

