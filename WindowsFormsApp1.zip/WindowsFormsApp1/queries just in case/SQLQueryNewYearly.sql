﻿
--CREATE VIEW Summary_MW_A AS 
--update SubGroup set TotInstCapacity = 2 
--TotInstCapacity
select System,FTH/(select count(distinct SubGroupID) from SubGroup)/(select sum(TotInstCapacity)/count( TotInstCapacity) from SubGroup),
ForcedCount/(select count(distinct SubGroupID) from SubGroup)/(select sum(TotInstCapacity)/count( TotInstCapacity) from SubGroup),MTH,MaintCount,PTH, PlannedCount from Wind_Farm_Summary_Category