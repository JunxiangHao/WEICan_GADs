﻿--select a.System, b.PercentHrs as oneFarm, a.PercentHrs as allFarm
--from master_Summary_MW_Avg_Monthly a
--inner join Summary_MW_Avg_Monthly b
--on a.System = b.System;

--select a.System, b.PercentCount as oneFarm, a.PercentCount as allFarm
--from master_Summary_MW_Avg_Monthly a
--inner join Summary_MW_Avg_Monthly b
--on a.System = b.System;

--select a.System, b.PercentHrs as oneFarm, a.PercentHrs as allFarm
--from master_Summary_Turbine_Avg_Monthly a
--inner join Summary_Turbine_Avg_Monthly b
--on a.System = b.System;

--select a.System, b.PercentCount as oneFarm, a.PercentCount as allFarm
--from master_Summary_Turbine_Avg_Monthly a
--inner join Summary_Turbine_Avg_Monthly b
--on a.System = b.System;

select a.System,a.TotalHrs as AverageHrs, isnull(b.TotalHrs,0) as WEICanHrs, isnull(c.TotalHrs,0) as TechnoCenterHrs, a.TotalCount AS AverageCount, isnull(b.TotalCount,0) as WEICanCount, isnull(c.TotalCount,0) as TechnoCenterCount 
from master_Summary_MW_Avg_Yearly2 a
inner join Summary_MW_Avg_Yealy_2 b
on a.System = b.System 
inner join TechnoCenter_Summary_perMW_Avg_Yearly_2 c
on b.System = c.System;


select a.System,a.TotalHrs as AverageHrs, isnull(b.TotalHrs,0) as WEICanHrs, isnull(c.TotalHrs,0) as TechnoCenterHrs, a.TotalCount AS AverageCount, isnull(b.TotalCount,0) as WEICanCount, isnull(c.TotalCount,0) as TechnoCenterCount 
from master_Summary_Turbine_Avg_Yearly2 a
full join Summary_Turbine_Avg_Yealy_2 b
on a.System = b.System 
full join TechnoCenter_Summary_perTurbine_Avg_Yearly_2 c
on b.System = c.System;