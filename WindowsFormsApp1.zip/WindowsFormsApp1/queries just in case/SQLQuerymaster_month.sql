﻿CREATE VIEW master_Summary_Turbine_Avg_Monthly AS 
select System,
CONVERT(DECIMAL(10,2),FTH/12) as FTH,
CONVERT(DECIMAL(10,2),ForcedCount/12) as ForcedCount,
CONVERT(DECIMAL(10,2),MTH/12) as MTH,
CONVERT(DECIMAL(10,2),MaintCount/12) as MaintCount,
CONVERT(DECIMAL(10,2),PTH/12) as PTH,
CONVERT(DECIMAL(10,2),PlannedCount/12) as PlannedCount,
CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs,
CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount,
PercentHrs,PercentCount from master_Summary_Turbine_Avg_Yearly2