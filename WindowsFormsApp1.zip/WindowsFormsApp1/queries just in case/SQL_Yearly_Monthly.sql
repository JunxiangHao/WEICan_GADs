﻿
CREATE VIEW Summary_MW_Avg_Yealy_1 AS
select a.System, 
ISNULL(sum(FTH)*count(TurbineCount)/sum(TotInstCapacity),0) as Avg_FTH, 
ISNULL(sum(ForcedCount)*count(TurbineCount)/sum(TotInstCapacity),0) as ForcedCount, 
ISNULL(sum(MTH)*count(TurbineCount)/sum(TotInstCapacity),0) as Avg_MTH, 
ISNULL(sum(MaintCount)*count(TurbineCount)/sum(TotInstCapacity),0) as  MaintCount, 
ISNULL(sum(PTH)*count(TurbineCount)/sum(TotInstCapacity),0) as Avg_PTH, 
ISNULL(sum(PlannedCount)*count(TurbineCount)/sum(TotInstCapacity),0) as PlannedCount,
ISNULL(sum(FTH)*count(TurbineCount)/sum(TotInstCapacity),0) + ISNULL(sum(MTH)*count(TurbineCount)/sum(TotInstCapacity),0) + ISNULL(sum(PTH)*count(TurbineCount)/sum(TotInstCapacity),0) as TotalHrs,
ISNULL(sum(ForcedCount)*count(TurbineCount)/sum(TotInstCapacity),0) + ISNULL(sum(MaintCount)*count(TurbineCount)/sum(TotInstCapacity),0) + ISNULL(sum(PlannedCount)*count(TurbineCount)/sum(TotInstCapacity),0) as TotalCount
--(Avg_FTH+Avg_MTH+Avg_PTH) as TotalHrs
--sum(FTH+MTH+PTH)*count(TurbineCount)/sum(TotInstCapacity) as TotalHrs
--(sum(ForcedCount)*count(TurbineCount)/sum(TotInstCapacity)+sum(MaintCount)*count(TurbineCount)/sum(TotInstCapacity)+sum(PlannedCount)*count(TurbineCount)/sum(TotInstCapacity)) as TotalCount

--(sum(FTH)/TotInstCapacity+sum(MTH)/TotInstCapacity+sum(PTH)/TotInstCapacity)/(select (sum(FTH)/TotInstCapacity+sum(MTH)/TotInstCapacity+sum(PTH)/TotInstCapacity) FROM SuperOutages a left join SubGroup b on a.SubGroupID = b.SubGroupID group by ()) as PercentHrs,
--(sum(ForcedCount)/TotInstCapacity+sum(MaintCount)/TotInstCapacity+sum(PlannedCount)/TotInstCapacity)/(select (sum(ForcedCount)/TotInstCapacity+sum(MaintCount)/TotInstCapacity+sum(PlannedCount)/TotInstCapacity) FROM SuperOutages a left join SubGroup b on a.SubGroupID = b.SubGroupID group by ()) as PercentCount
FROM SuperOutages a
left join SubGroup b
on a.SubGroupID = b.SubGroupID
GROUP BY a.System