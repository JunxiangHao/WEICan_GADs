﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Interop.Access;
using Access = Microsoft.Office.Interop.Access;
using Microsoft.VisualStudio.CommandBars;
using System.Data.SqlClient;
using Microsoft.VisualBasic.FileIO;
using System.Data.Common;
using System.Configuration;

using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Windows.Forms.DataVisualization.Charting;


namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        Microsoft.Office.Interop.Excel.Application excelApplication;

        string srcPath;
        Microsoft.Office.Interop.Excel.Workbook srcWorkBook;
        Microsoft.Office.Interop.Excel.Worksheet srcWorkSheet;

        string destPath;
        Microsoft.Office.Interop.Excel.Workbook destworkBook;
        Microsoft.Office.Interop.Excel.Worksheet destworkSheet;

        Microsoft.Office.Interop.Excel.Range from;
        Microsoft.Office.Interop.Excel.Range to;

        DataSet dataSet6 = new DataSet();
        public Form2()
        {
            InitializeComponent();
           


        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox_path.Text = openFileDialog1.FileName;
            }
               

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string PathConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox_path.Text + ";Extended Properties=\"Excel 12.0 Xml; HDR = YES;\";";
                OleDbConnection conn = new OleDbConnection(PathConn);
                if (!String.IsNullOrEmpty(textBox_sheet.Text))
                {
                    OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("Select * from [" + textBox_sheet.Text + "$]", conn);
                    System.Data.DataTable dt = new System.Data.DataTable();

                    myDataAdapter.Fill(dt);

                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("please inter a sheet name to view the data");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }

        private void textBox_path_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                excelApplication = new Microsoft.Office.Interop.Excel.Application();

                srcPath = textBox_path.Text;
                srcWorkBook = excelApplication.Workbooks.Open(srcPath, ReadOnly: false);

                if (String.IsNullOrEmpty(textBox_sheet.Text))
                {
                    srcWorkSheet = srcWorkBook.Worksheets[1];
                }
                else
                {
                    srcWorkSheet = srcWorkBook.Worksheets[textBox_sheet.Text];
                }


                destPath = textBox_path2.Text;
                destworkBook = excelApplication.Workbooks.Open(destPath, ReadOnly: false);

                if (String.IsNullOrEmpty(textBox_sheet2.Text))
                {
                    destworkSheet = destworkBook.Worksheets[1];
                }
                else
                {
                    destworkSheet = destworkBook.Worksheets[textBox_sheet2.Text];
                }
                //  srcWorkSheet.Columns.ClearFormats();
                //  srcWorkSheet.Rows.ClearFormats();
                //  int rangeColumns = srcWorkSheet.UsedRange.Columns.Count;
                //  int rangeRows = srcWorkSheet.UsedRange.Rows.Count;

                Excel.Range last = srcWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                Excel.Range range = srcWorkSheet.get_Range("A1", last);
                int lastUsedRow = last.Row;
                int lastUsedColumn = last.Column;

                from = range;//srcWorkSheet.Range["A1:"+last];
                to = destworkSheet.Range["A1:AW500"];

                from.Copy(to);

                //destworkBook.SaveAs(destPath);
                destworkBook.Save();
                destworkBook.Close();
                srcWorkBook.Close(false, null, null);
                excelApplication.Quit();

                MessageBox.Show("  import successfully  ");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox_path2.Text = openFileDialog1.FileName;
            }
            

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            string connectionString = ConfigurationManager.AppSettings["connectionString"];
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connectionString;
            con.Open();

            string farmName = textBox_farm.Text;
            string SuperOutages = farmName + "_SuperOutages";
            string Wind_Farm_Summary_Category = farmName + "_Wind_Farm_Summary_Category";
            string Wind_Farm_Summary_Code = farmName + "_Wind_Farm_Summary_Code";
            string Summary_MW = farmName + "_Summary_MW";
            string Summary_MW_Category_Month = farmName + "_Summary_perMW_Category_Month";
            string Summary_MW_Category_Year = farmName + "_Summary_perMW_Category_Year";
            string Summary_MW_Avg_Yealy_1 = farmName + "_Summary_perMW_Avg_Yearly_1";
            string Summary_MW_Avg_Yealy_2 = farmName + "_Summary_perMW_Avg_Yearly_2";

            string Summary_MW_Avg_Monthly = farmName + "_Summary_perMW_Avg_Monthly";
            string Summary_Turbine = farmName + "_Summary_Turbine";
            string Summary_Turbine_Category_Month = farmName + "_Summary_perTurbine_Category_Month";
            string Summary_Turbine_Category_Year = farmName + "_Summary_perTurbine_Category_Year";
            string Summary_Turbine_Avg_Yealy_1 = farmName + "_Summary_perTurbine_Avg_Yearly_1";
            string Summary_Turbine_Avg_Yealy_2 = farmName + "_Summary_perTurbine_Avg_Yearly_2";
            string Summary_Turbine_Avg_Monthly = farmName + "_Summary_perTurbine_Avg_Monthly";
            string Summary_Monthly_Total = farmName + "_Summary_Monthly_Total2";

            SqlDataAdapter myDataAdapter = new SqlDataAdapter("select a.System, b.PercentHrs as oneFarm, a.PercentHrs as allFarm " +
                    "from master_Summary_MW_Avg_Monthly a " +
                    "full join "+Summary_MW_Avg_Monthly+" b " +
                    "on a.System = b.System", con);
            System.Data.DataTable dt = new System.Data.DataTable();
            myDataAdapter.Fill(dt);
            dataSet6.Tables.Add(dt);


            chart1.Titles.Add("Downtime Hours Per MV");
            chart1.Legends["Legend1"].Docking = Docking.Bottom;
            chart1.Legends["Legend1"].Alignment = StringAlignment.Center;
            chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;


            chart1.Series.Add(farmName);
            chart1.Series[farmName].ChartType = SeriesChartType.Bar;
            chart1.Series[farmName].ChartArea = "ChartArea1";
            chart1.Series[farmName].Label = "#PERCENT";
            chart1.Series[farmName].YValueMembers = "oneFarm";
            chart1.Series[farmName].XValueMember = "System";



            chart1.Series["Average"].Label = "#PERCENT";
            chart1.Series["Average"].ChartType = SeriesChartType.Bar;
            chart1.Series["Average"].XValueMember = "System";
            chart1.Series["Average"].YValueMembers = "allFarm";
            chart1.Series["Average"].Color = Color.Gray;


            chart1.DataSource = dataSet6.Tables[0];
            chart1.DataBind();

            
            //chart1.Series["TechnoCenter"].AxisLabel = "PERCENT";
            //chart1.Series["Average"].AxisLabel = "PERCENT";
            
            chart1.Series["Average"].Points[3].Label = "First Point";
            chart1.Series["Average"].Points[3].Color = Color.Red;
            chart1.Series[farmName].Points[2].Color = Color.Orange;





            SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Outages'", con);
            System.Data.DataTable dtp = new System.Data.DataTable();
            myDataAdapterp.Fill(dtp);
            List<String> listp = new List<string>();
            foreach (DataRow row in dtp.Rows)
            {
                listp.Add(row[0].ToString().Split('_')[0]);

            }
            string subQuery1 = "select a.System, a.TotalHrs as AverageHrs, a.TotalCount AS AverageCount ";
            string subQuery2 = "from master_Summary_MW_Avg_Yearly2 a ";
            foreach (String Name in listp)
            {
                subQuery1 += ", isnull(" + Name + ".TotalHrs,0) as " + Name + "Hrs, isnull(" + Name + ".TotalCount,0) as " + Name + "Count ";
                subQuery2 += "full join "+Name+ "_Summary_perMW_Avg_Yearly_2 " + Name + " " +
                    "on a.System = " + Name + ".System ";
            }
            string subQuery3 = subQuery1 + subQuery2;
                SqlDataAdapter myDataAdapter7 = new SqlDataAdapter(subQuery3, con);
            System.Data.DataTable dt7 = new System.Data.DataTable();
            myDataAdapter7.Fill(dt7);
            dataSet6.Tables.Add(dt7);




            chart2.Legends["Legend1"].Docking = Docking.Bottom;
            chart2.Legends["Legend1"].Alignment = StringAlignment.Center;
            chart2.Titles.Add("Downtime Hours Per MV");
            chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1;


            chart2.Series["Average"].ChartType = SeriesChartType.StepLine;
            //chart2.Series["Average"].Label = "#PERCENT";
            chart2.Series["Average"].XValueMember = "System";
            chart2.Series["Average"].YValueMembers = "AverageHrs";
            chart2.Series["Average"].Color = Color.Gray;
            chart2.Series["Average"].MarkerColor = Color.DarkGray;
            chart2.Series["Average"].MarkerSize = 8;
            chart2.Series["Average"].MarkerStyle = MarkerStyle.Cross;


            chart2.Series.Add(farmName);
            chart2.Series[farmName].ChartType = SeriesChartType.Point;
            chart2.Series[farmName].ChartArea = "ChartArea1";
            //chart2.Series["TechnoCenter"].Label = "#PERCENT";
            chart2.Series[farmName].Color = Color.Black;
            chart2.Series[farmName].XValueMember = "System";
            chart2.Series[farmName].YValueMembers = farmName+"Hrs";
            chart2.Series[farmName].MarkerColor = Color.Black;
            chart2.Series[farmName].MarkerSize = 9;
            chart2.Series[farmName].MarkerStyle = MarkerStyle.Triangle;

            foreach (String Name in listp)
            {
                if (Name != farmName)
                {
                    chart2.Series.Add(Name);
                    chart2.Series[Name].ChartType = SeriesChartType.Point;
                    chart2.Series[Name].ChartArea = "ChartArea1";
                    //chart2.Series["WEICan"].Label = "#PERCENT";
                    chart2.Series[Name].Color = Color.Gray;
                    chart2.Series[Name].XValueMember = "System";
                    chart2.Series[Name].YValueMembers = Name+"Hrs";
                    chart2.Series[Name].MarkerColor = Color.Gray;
                    chart2.Series[Name].MarkerSize = 5;
                    chart2.Series[Name].MarkerStyle = MarkerStyle.Circle;
                }
            }

            chart2.DataSource = dataSet6.Tables[1];
            chart2.DataBind();


            foreach (String Name in listp)
            {
                string Q1 = "CREATE VIEW " + Name + "_Availablity AS select(SUM(CTH +RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH, 0) + isnull(MTH, 0) + isnull(PTH, 0) + isnull(EFDTH, 0) + isnull(EMDTH, 0) + isnull(EPDTH, 0) + isnull(RUTH, 0)))/ SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS " + Name + "_Availablity from " + Name + "_Performance";
                SqlCommand cmd = new SqlCommand(Q1, con);
                cmd.ExecuteNonQuery();

                /*string Q2 = "CREATE VIEW WEICan_Availablity AS select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS WEICan_Availablity from Performance";
                SqlCommand cmd2 = new SqlCommand(Q2, con);
                cmd2.ExecuteNonQuery();*/

                string Q3 = "CREATE VIEW " + Name + "_capacity AS select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(isnull(TotInstCapacity,0)/isnull(TurbineCount,0)) from TechnoCenter_SubGroup)) as " + Name + "_capacity FROM " + Name + "_Performance";
                SqlCommand cmd3 = new SqlCommand(Q3, con);
                cmd3.ExecuteNonQuery();

                /*string Q4 = "CREATE VIEW WEICan_capacity AS select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(SystemMW) from TechnoCenter_SubGroup)) as WEICan_capacity FROM Performance";
                SqlCommand cmd4 = new SqlCommand(Q4, con);
                cmd4.ExecuteNonQuery();*/
            }
            string ava = "CREATE VIEW Availablity AS select * from "+ farmName+ "_Availablity ";
            string cap = "CREATE VIEW Capacity AS select * from " + farmName + "_capacity ";
            foreach (String Name in listp)
            {
                if (Name != farmName)
                {
                    ava += ", " + Name + "_Availablity ";
                    cap += ", " + Name + "_capacity ";
                }
            }
            string Q5 = ava;
            SqlCommand cmd5 = new SqlCommand(Q5, con);
            cmd5.ExecuteNonQuery();

            string Q6 = cap;
            SqlCommand cmd6 = new SqlCommand(Q6, con);
            cmd6.ExecuteNonQuery();

            string ava2 = "CREATE VIEW Availablity2 AS select Field from Availablity UNPIVOT (Field for ColumnName IN ([" + farmName + "_Availablity] ";
            string cap2 = "CREATE VIEW Capacity2 AS select Field from Capacity UNPIVOT (Field for ColumnName IN ([" + farmName + "_capacity] ";
            foreach (String Name in listp)
            {
                if (Name != farmName)
                {
                    ava2 += ", [" + Name + "_Availablity] ";
                    cap2 += ", [" + Name + "_capacity] ";
                }
            }

            ava2 += ")) unpvt";
            cap2 += ")) unpvt";
            string Q7 = ava2;
            SqlCommand cmd7 = new SqlCommand(Q7, con);
            cmd7.ExecuteNonQuery();

            string Q8 = cap2;
            SqlCommand cmd8 = new SqlCommand(Q8, con);
            cmd8.ExecuteNonQuery();


            SqlDataAdapter myDataAdapter5 = new SqlDataAdapter("select Field , (select avg(Field) from Availablity2) as Average from Availablity2", con);
            System.Data.DataTable dt5 = new System.Data.DataTable();
            myDataAdapter5.Fill(dt5);
            dataSet6.Tables.Add(dt5);

            SqlDataAdapter myDataAdapter6 = new SqlDataAdapter("select Field , (select avg(Field) from Capacity2) as Average from Capacity2", con);
            System.Data.DataTable dt6 = new System.Data.DataTable();
            myDataAdapter6.Fill(dt6);
            dataSet6.Tables.Add(dt6);

            foreach (String Name in listp)
            {
                string Q11 = "drop VIEW "+Name+"_Availablity ";
                SqlCommand cmd1 = new SqlCommand(Q11, con);
                cmd1.ExecuteNonQuery();

                /*string Q21 = "drop VIEW WEICan_Availablity ";
                SqlCommand cmd21 = new SqlCommand(Q21, con);
                cmd21.ExecuteNonQuery();*/

                string Q31 = "drop VIEW " + Name + "_capacity ";
                SqlCommand cmd31 = new SqlCommand(Q31, con);
                cmd31.ExecuteNonQuery();

                /*string Q41 = "drop VIEW WEICan_capacity ";
                SqlCommand cmd41 = new SqlCommand(Q41, con);
                cmd41.ExecuteNonQuery();*/
            }
            string Q51 = "drop VIEW Availablity ";
            SqlCommand cmd51 = new SqlCommand(Q51, con);
            cmd51.ExecuteNonQuery();

            string Q61 = "drop VIEW Capacity ";
            SqlCommand cmd61 = new SqlCommand(Q61, con);
            cmd61.ExecuteNonQuery();
            string Q71 = "drop VIEW Availablity2 ";
            SqlCommand cmd71 = new SqlCommand(Q71, con);
            cmd71.ExecuteNonQuery();

            string Q81 = "drop VIEW Capacity2 ";
            SqlCommand cmd81 = new SqlCommand(Q81, con);
            cmd81.ExecuteNonQuery();



            
            chart3.Legends["Legend1"].Docking = Docking.Bottom;
            chart3.Legends["Legend1"].Alignment = StringAlignment.Center;
            chart3.Titles.Add("Resourse Net Capacity Factor");
            chart3.ChartAreas["ChartArea1"].AxisX.Interval = 1;


            chart3.Series["Weighted average across all turbines"].ChartType = SeriesChartType.Line;
            chart3.Series["Weighted average across all turbines"].YValueMembers = "Average";
            chart3.Series["Weighted average across all turbines"].Color = Color.DarkGray;
            //chart3.Series["Weighted average across all turbines"].Points[0].Label = "TechnoCenter";



            chart3.Series.Add("data from all farms");
            chart3.Series["data from all farms"].ChartType = SeriesChartType.Point;
            chart3.Series["data from all farms"].ChartArea = "ChartArea1";
            chart3.Series["data from all farms"].Color = Color.Black;
            chart3.Series["data from all farms"].YValueMembers = "Field";
            chart3.Series["data from all farms"].MarkerSize = 6;
            chart3.Series["data from all farms"].MarkerStyle = MarkerStyle.Circle;


            chart3.DataSource = dataSet6.Tables[2];
            chart3.DataBind();
            chart3.Series["data from all farms"].Points[0].Label = farmName;
            chart3.Series["data from all farms"].Points[0].Color = Color.Red;

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}
