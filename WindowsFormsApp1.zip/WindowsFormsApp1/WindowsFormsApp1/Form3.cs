﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Interop.Access;
using Access = Microsoft.Office.Interop.Access;
using Microsoft.VisualStudio.CommandBars;
using System.Data.SqlClient;
using Microsoft.VisualBasic.FileIO;

using System.Data.Common;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        DataTable traData = new DataTable();
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Multiselect = true;
            openFileDialog1.Title = "Please Select csv files to import";
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                /*foreach (String excelFile in openFileDialog1.FileNames)
                { 
                }*/
                this.textBox_path.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                /*string PathConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox_path.Text + ";Extended Properties=\"Excel 12.0 Xml; HDR = YES;\";";
                   OleDbConnection conn = new OleDbConnection(PathConn);
                   if (!String.IsNullOrEmpty(textBox_sheet.Text))
                   {
                       OleDbDataAdapter da = new OleDbDataAdapter("Select * from [" + textBox_sheet.Text + "$]", conn);
                       //System.Data.DataTable dt = new System.Data.DataTable();

                       da.Fill(dsContacts);
                       string test1 = dsContacts.Tables[0].Columns.Count.ToString();
                       string test2 = dsContacts.Tables[0].Rows.Count.ToString();
                       dgContacts.DataSource = dsContacts.Tables[0];
                       // dataGridView1.DataSource = dt;
                   }
                   else
                   {
                       MessageBox.Show("please inter a sheet name to view the data");
                   }*/
                //sContacts.Tables[0]= GetDataTableFromCSVFile(textBox_path.Text);
                traData = GetDataTableFromCSVFile(textBox_path.Text);
                dgContacts.DataSource = traData;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private static DataTable GetDataTableFromCSVFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] {","});
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datacolumn1 = new DataColumn(column);
                        datacolumn1.AllowDBNull = true;
                        csvData.Columns.Add(datacolumn1);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        for(int i = 0; i < fieldData.Length;i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return null;
            }
            return csvData;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox_path2.Text + ";";
                connection.Open();

                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from "+ textBox_sheet2.Text;
                //command.ExecuteNonQuery();
                OleDbDataAdapter da2 = new OleDbDataAdapter(command);
                OleDbCommandBuilder builder = new OleDbCommandBuilder(da2);
                da2.Fill(dataSet2);
                dataGridView1.DataSource = dataSet2.Tables[0];

               
                //builder.GetInsertCommand();
                int totalCol = dataSet2.Tables[0].Columns.Count;
                int totalRow = dataSet2.Tables[0].Rows.Count;
                
                foreach (DataRow r in traData.Rows)
                {
                    DataRow dr = dataSet2.Tables[0].NewRow();

                    for (int a = 0; a < totalCol; a++){
                        dr[a] = r[a];
                    }
                    
                    dataSet2.Tables[0].Rows.Add(dr);
                    //builder.GetInsertCommand();
                }
                da2.UpdateCommand = builder.GetUpdateCommand();
                da2.Update(dataSet2);






                connection.Close();
                MessageBox.Show("succeed");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox_path2.Text = openFileDialog1.FileName;
            }
        }
    }
}
