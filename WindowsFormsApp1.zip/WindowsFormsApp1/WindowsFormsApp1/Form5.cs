﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Interop.Access;
using Access = Microsoft.Office.Interop.Access;
using Microsoft.VisualStudio.CommandBars;
using System.Data.SqlClient;
using Microsoft.VisualBasic.FileIO;
using System.Data.Common;
using System.Configuration;
namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public static double V1;
        
        public static int V2;
        public static double V3;
        public Form5()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            V1 = double.Parse(textBox1.Text);
            V2 = int.Parse(textBox2.Text);
            V3 = double.Parse(textBox3.Text);
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                SqlCommand cmd = new SqlCommand("update SubGroup set TotInstCapacity =" + V3 + " , TurbineCount = " + V2 + ", SystemMW = " + V1 + "", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("succeed");
                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }



        }
    }
}
