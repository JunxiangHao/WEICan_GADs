﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
//using ExcelToAccessLib;
//using Microsoft.Office.Interop.Access;
using Access = Microsoft.Office.Interop.Access;
using System.Configuration;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {

            
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=GADS-PC;Initial Catalog=StoreDB;Integrated Security=True;Pooling=False");
                con.Open();
                SqlCommand cmd = new SqlCommand("CREATE DATABASE  " + textBox_path.Text + "", con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd2 = new SqlCommand("Select * into [" + textBox_path.Text + "].dbo.[Sys-Com Codes] from [StoreDB].dbo.[Sys-Com Codes]", con);
                cmd2.ExecuteNonQuery();

                con.Close();


                System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

                config.AppSettings.Settings["connectionString"].Value = "Data Source=GADS-PC;Initial Catalog=" + textBox_path.Text + ";Integrated Security=True;Pooling=False";
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("appSettings");
                MessageBox.Show("succeed to create and connect to this database");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox_path.Text +";";
                connection.Open();
                checkConnection.Text = "Connection Successful";
                connection.Close();
                connection.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not much, just don't want to work.");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hi bro, Sup?");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("select name from sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb')", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString());

                }
                comboBox1.DataSource = listp;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(comboBox1.Text);
            textBox1.Text = comboBox1.Text;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

                config.AppSettings.Settings["connectionString"].Value = "Data Source=GADS-PC;Initial Catalog=" + textBox1.Text + ";Integrated Security=True;Pooling=False";
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("appSettings");
                MessageBox.Show("succeed to switch to " + textBox1.Text + " database");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //textBox1.Text = comboBox1.Text;
        }
    }
}
