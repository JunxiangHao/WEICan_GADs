﻿/*
 dataset1= Contains performance table data (commissioning year, system MW... etc) for each farm
 dataset2= one table for performance/outages/SubGroup 12 files gathered together.
 dataset3= data from CSV files (Performace/outages/SubGroup), one table for one month 
 (no dataset4)
 dataset5= 14 tables for each farm; 6 tables for master list. Master list combines data from all farms. Number of tables in master list does not change.
 dataset6= sourse tables for charts 
 dataset7= GADS description second part
 dataset8= Gads descriptopn first part
 dataset9= for the historical function, unavailable

 Last updated on:2018-08-22

 Last change :

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using ExcelLibrary.CompoundDocumentFormat;
using ExcelLibrary.SpreadSheet;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Interop.Access;
using Access = Microsoft.Office.Interop.Access;
using Microsoft.VisualStudio.CommandBars;
using System.Data.SqlClient;
using Microsoft.VisualBasic.FileIO;
using System.Data.Common;
using System.Configuration;

using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
       // public static int totalCo;
        List<String> list1 = new List<string>();
        DataSet dataset3 = new DataSet();
        DataSet dataSet5 = new DataSet();
        List<System.IO.FileInfo> fList2 = new List<System.IO.FileInfo>();
        DataSet dataSet6 = new DataSet();
        DataSet dataSet7 = new DataSet();
        DataSet dataSet8 = new DataSet();
        DataSet dataSet9 = new DataSet();


        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //store the selected files and stored the name 
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Multiselect = true;
            openFileDialog1.Title = "Please Select CSV files to import";
            List<System.IO.FileInfo> fList = new List<System.IO.FileInfo>();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (String excelFile in openFileDialog1.FileNames)
                {
                    try
                    {
                        fList.Add(new System.IO.FileInfo(excelFile));
                        fList2.Add(new System.IO.FileInfo(excelFile));
                        list1.Add(excelFile);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: "+ ex.Message);
                    }
                }
                comboBox1.DataSource = fList;
                //comboBox1.Text;
                //String a = comboBox1.SelectedValue.ToString();
                // this.textBox_path.Text = openFileDialog1.FileName;
            }
            try
            {


                string CompanyName = openFileDialog1.FileNames[0].Split('\\').Last();
                string TableSub = openFileDialog1.FileNames[0].Split('\\').Last();
                string TableSubNa = TableSub.Split(' ').Last();
                string TableSubName = TableSubNa.Split('.')[0];
                string FullName = CompanyName + "_" + TableSubName;
                textBox_sheet2.Text = TableSubName;
                textBox_farm.Text = CompanyName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)//copy the select CSV files to dataset3
        {
            try
            {


                foreach (String source in list1)
                {
                    try
                    {
                        /* String PathConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + source + ";Extended Properties=\"Excel 12.0 Xml; HDR = YES;\";";
                         OleDbConnection conn = new OleDbConnection(PathConn);

                         OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("Select * from [" + textBox_sheet.Text + "$]", conn);

                         System.Data.DataTable dt = new System.Data.DataTable();

                         myDataAdapter.Fill(dt);
                         dataset3.Tables.Add(dt);
                         */
                        System.Data.DataTable dt = new System.Data.DataTable();
                        dt = GetDataTableFromCSVFile(source);

                        dataset3.Tables.Add(dt);
                        //totalCo = dataset3.Tables[0].Columns.Count;


                    }
                    


                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex);
                    }

                }

                textBox_farm.Text = dataset3.Tables[0].Rows[0][1].ToString();
                if (dataset3.Tables[0].Columns[1].ColumnName.ToString()=="Region")
                {
                    textBox_farm.Text = dataset3.Tables[0].Rows[0][2].ToString();
                }
                if (dataset3.Tables[0].Columns[1].ColumnName.ToString() == "Group_Id")
                {
                    textBox_farm.Text = dataset3.Tables[0].Rows[0][0].ToString();
                }
                //string aaa = 
                textBox_sheet2.Text = textBox_farm.Text + "_" + textBox_sheet2.Text;
                comboBox2.DataSource = fList2;
            }
            // MessageBox.Show("import succeed");
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }
        private static DataTable GetDataTableFromCSVFile(string csv_file_path)//parser to read and modify CSV files and copy to each tables in dataset3
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datacolumn1 = new DataColumn(column);
                        datacolumn1.AllowDBNull = true;
                        csvData.Columns.Add(datacolumn1);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = "0";
                            }
                            if (fieldData[i] == null)
                            {
                                fieldData[i] = "0";
                            }
                            if (fieldData[i] == "N/A")
                            {
                                fieldData[i] = "0";
                            }
                          
                        }
                        csvData.Rows.Add(fieldData);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return null;
            }
            return csvData;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataSet dataSet2 = new DataSet();
            try
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox_path2.Text + ";";
                connection.Open();

                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from " + textBox_sheet2.Text;
                //command.ExecuteNonQuery();
                OleDbDataAdapter da2 = new OleDbDataAdapter(command);
                OleDbCommandBuilder builder = new OleDbCommandBuilder(da2);
                da2.Fill(dataSet2);
                //dataGridView1.DataSource = dataSet2.Tables[0];


                //builder.GetInsertCommand();
                int totalCol = dataSet2.Tables[0].Columns.Count;
                int totalRow = dataSet2.Tables[0].Rows.Count;

                for (int count = 0; count < list1.Count; count++)
                {
                    
                    foreach (DataRow r in dataset3.Tables[count].Rows)
                    {
                        DataRow dr = dataSet2.Tables[0].NewRow();

                        for (int a = 0; a < totalCol; a++)
                        {
                            dr[a] = r[a];
                        }

                        dataSet2.Tables[0].Rows.Add(dr);
                        //builder.GetInsertCommand();
                    }
                }


                da2.UpdateCommand = builder.GetUpdateCommand();
                da2.Update(dataSet2);
                //fList2.Add(new System.IO.FileInfo(textBox_path2.Text));
                dataGridView1.DataSource = dataSet2.Tables[0];
                //MessageBox.Show("export succeed");




                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox_path2.Text = openFileDialog1.FileName;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = dataset3.Tables[comboBox1.SelectedIndex];
            //comboBox1.SelectedIndex
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dataset3.Tables[comboBox2.SelectedIndex];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                string farmName = textBox_farm.Text;
                string Summary_MW_Avg_Monthly = farmName + "_Summary_perMW_Avg_Monthly";
                SqlDataAdapter myDataAdapter = new SqlDataAdapter("select a.System, b.TotalHrs as oneFarm, a.TotalHrs as allFarm, c.TotalHrs as Last " +
                            "from master_Summary_MW_Avg_Monthly a " +
                            "full join " + Summary_MW_Avg_Monthly + " b " +
                            "on a.System = b.System " +
                            "full join Last_" + Summary_MW_Avg_Monthly + " c" +
                            "on a.System = c.System ", con);
                System.Data.DataTable dt = new System.Data.DataTable();
                myDataAdapter.Fill(dt);
                dataSet9.Tables.Add(dt);

                //CONVERT(DECIMAL(10,2),FTH/12)
                SqlDataAdapter myDataAdapter2 = new SqlDataAdapter("select a.System, b.TotalCount as oneFarm, a.TotalCount as allFarm, c.TotalCount as Last " +
                    "from master_Summary_MW_Avg_Monthly a " +
                    "full join " + Summary_MW_Avg_Monthly + " b " +
                    "on a.System = b.System" +
                    "full join Last_" + Summary_MW_Avg_Monthly + " c" +
                    "on a.System = c.System ", con);
                System.Data.DataTable dt2 = new System.Data.DataTable();
                myDataAdapter2.Fill(dt2);
                dataSet9.Tables.Add(dt2);



                //chart11.Titles.Add("Downtime Hours Per MW");
                chart11.Legends["Legend1"].Docking = Docking.Bottom;
                chart11.Legends["Legend1"].Alignment = StringAlignment.Center;
                chart11.ChartAreas["ChartArea1"].AxisX.Interval = 1;


                chart11.Series.Add("CurrentYear");
                chart11.Series["CurrentYear"].ChartType = SeriesChartType.Bar;
                chart11.Series["CurrentYear"].ChartArea = "ChartArea1";

                chart11.Series["CurrentYear"].YValueMembers = "oneFarm";
                chart11.Series["CurrentYear"].XValueMember = "System";


                chart11.Series.Add("CurrentAverage");

                chart11.Series["CurrentAverage"].ChartType = SeriesChartType.Bar;
                chart11.Series["CurrentAverage"].XValueMember = "System";
                chart11.Series["CurrentAverage"].YValueMembers = "allFarm";
                chart11.Series["CurrentAverage"].Color = Color.Gray;


                chart11.Series.Add("LastYear");
                chart11.Series["LastYear"].ChartType = SeriesChartType.Bar;
                chart11.Series["LastYear"].ChartArea = "ChartArea1";

                chart11.Series["LastYear"].YValueMembers = "Last";
                chart11.Series["LastYear"].XValueMember = "System";


                chart11.DataSource = dataSet9.Tables[0];
                chart11.DataBind();






                //chart12.Titles.Add("Downtime Occurences Per MW");
                chart12.Legends["Legend1"].Docking = Docking.Bottom;
                chart12.Legends["Legend1"].Alignment = StringAlignment.Center;
                chart12.ChartAreas["ChartArea1"].AxisX.Interval = 1;


                chart11.Series.Add("CurrentYear");
                chart11.Series["CurrentYear"].ChartType = SeriesChartType.Bar;
                chart11.Series["CurrentYear"].ChartArea = "ChartArea1";

                chart11.Series["CurrentYear"].YValueMembers = "oneFarm";
                chart11.Series["CurrentYear"].XValueMember = "System";


                chart11.Series.Add("CurrentAverage");

                chart11.Series["CurrentAverage"].ChartType = SeriesChartType.Bar;
                chart11.Series["CurrentAverage"].XValueMember = "System";
                chart11.Series["CurrentAverage"].YValueMembers = "allFarm";
                chart11.Series["CurrentAverage"].Color = Color.Gray;


                chart11.Series.Add("LastYear");
                chart11.Series["LastYear"].ChartType = SeriesChartType.Bar;
                chart11.Series["LastYear"].ChartArea = "ChartArea1";

                chart11.Series["LastYear"].YValueMembers = "Last";
                chart11.Series["LastYear"].XValueMember = "System";

                chart12.DataSource = dataSet9.Tables[1];
                chart12.DataBind();

                con.Close();
                MessageBox.Show("succeed");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
           

            /*string provider = ConfigurationManager.AppSettings["provider"];
            string connectionString = ConfigurationManager.AppSettings["connectionString"];

            DbProviderFactory factory = DbProviderFactories.GetFactory(provider);
            
            using (DbConnection connection = factory.CreateConnection())
            {
                if(connection == null)
                {
                    Console.WriteLine("Connection Error");
                    Console.ReadLine();
                    return;
                }

                connection.ConnectionString = connectionString;

                connection.Open();

                DbCommand command = factory.CreateCommand();

                if (command == null)
                {
                    Console.WriteLine("Command Error");
                    Console.ReadLine();
                    return;
                }

                command.Connection = connection;
                command.CommandText = "Select * from test1";


            }
            DbConnection conn = factory.CreateConnection();
            conn.ConnectionString = connectionString;
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn.ConnectionString, SqlBulkCopyOptions.KeepIdentity))
            {
                foreach(DataColumn col in )
            }*/

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {


                DataSet dataSet2 = new DataSet();
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from " + textBox_sheet2.Text, con);


                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                sda.Fill(dataSet2);
                //dataGridView1.DataSource = dataSet2.Tables[0];


                //builder.GetInsertCommand();
                int totalCol = dataSet2.Tables[0].Columns.Count;
                int totalRow = dataSet2.Tables[0].Rows.Count;
                

                for (int count = 0; count < list1.Count; count++)
                {

                    foreach (DataRow r in dataset3.Tables[count].Rows)
                    {
                        DataRow dr = dataSet2.Tables[0].NewRow();

                        for (int a = 1; a < dataset3.Tables[count].Columns.Count+1; a++)
                        {
                            dr[a] = r[a - 1];
                        }

                        dataSet2.Tables[0].Rows.Add(dr);
                        //builder.GetInsertCommand();
                    }
                }


                sda.UpdateCommand = builder.GetUpdateCommand();
                sda.Update(dataSet2);
                //fList2.Add(new System.IO.FileInfo(textBox_path2.Text));
                dataGridView1.DataSource = dataSet2.Tables[0];
                MessageBox.Show("export succeed, please close the window and open it again to export other file(s)");




                con.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.AppSettings["connectionString"];
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connectionString;
            con.Open();
            /*list1.Clear();
            dataset3.Clear();
            fList2.Clear();*/
            string Qdelete1 = "drop VIEW master_Summary_Turbine_Avg_Monthly ";
            SqlCommand cmd1 = new SqlCommand(Qdelete1, con);
            cmd1.ExecuteNonQuery();

            string Qdelete2 = "drop VIEW master_Summary_Turbine_Avg_Yearly2 ";
            SqlCommand cmd2 = new SqlCommand(Qdelete2, con);
            cmd2.ExecuteNonQuery();

            string Qdelete3 = "drop VIEW master_Summary_Turbine_Avg_Yearly_N ";
            SqlCommand cmd3 = new SqlCommand(Qdelete3, con);
            cmd3.ExecuteNonQuery();

            string Qdelete4 = "drop VIEW master_Summary_MW_Avg_Monthly ";
            SqlCommand cmd4 = new SqlCommand(Qdelete4, con);
            cmd4.ExecuteNonQuery();

            string Qdelete5 = "drop VIEW master_Summary_MW_Avg_Yearly2 ";
            SqlCommand cmd5 = new SqlCommand(Qdelete5, con);
            cmd5.ExecuteNonQuery();

            string Qdelete6 = "drop VIEW master_Summary_MW_Avg_Yearly_N ";
            SqlCommand cmd6 = new SqlCommand(Qdelete6, con);
            cmd6.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("succeed");
        }

        private void button8_Click(object sender, EventArgs e)
        {
           /* string connectionString = ConfigurationManager.AppSettings["connectionString"];
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connectionString;
            
            SqlCommand cmd = new SqlCommand("CREATE VIEW "+ textBox_view.Text + " as select * from [Outages] a inner join [Sys-Com Codes] b on a.SysCompCode = b.Entry ", con);
            //cmd.Parameters.Add("@NewOutages", SqlDbType.Text);
            //cmd.Parameters["@NewOutages"].Value = textBox_view.Text;
           // cmd.Parameters.AddWithValue("@NewOutages", textBox_view.Text);

            con.Open();
            cmd.ExecuteNonQuery();
          
            con.Close();*/
        }

        private void button9_Click(object sender, EventArgs e)//connect to database and defind tables for 3 new standard tables (Outages, performace, subgroup)
        {
            try
            {
                //Select * into [StoreDBtest].dbo.[Sys-Com Codes] from [StoreDB].dbo.[Sys-Com Codes]
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                string farm_outages = textBox_farm.Text + "_Outages";
                string farm_performance = textBox_farm.Text + "_Performance";
                string farm_SubGroup = textBox_farm.Text + "_SubGroup";

                SqlCommand cmd1 = new SqlCommand("CREATE TABLE [dbo].[" + farm_outages + "] ( " +
                    "[PK]           INT          IDENTITY (1, 1) NOT NULL, " +
                    "[UtilityID]    NCHAR (10)   NULL, " +
                    "[PlantIDName]  VARCHAR (50) NULL, " +
                    "[GroupIDName]  VARCHAR (50) NULL, " +
                    "[SubGroupID]   VARCHAR (50) NULL, " +
                    "[ReptMonth]    INT          NULL, " +
                    "[ReptYear]     INT          NULL, " +
                    "[SysCompCode]  INT          NULL, " +
                    "[FTH]          FLOAT (53)   NULL, " +
                    "[ForcedCount]  FLOAT (53)   NULL, " +
                    "[MTH]          FLOAT (53)   NULL, " +
                    "[MaintCount]   FLOAT (53)   NULL," +
                    "[PTH]          FLOAT (53)   NULL, " +
                    "[PlannedCount] FLOAT (53)   NULL, " +
                    "[EFDTH]        FLOAT (53)   NULL, " +
                    "[EMDTH]        FLOAT (53)   NULL, " +
                    "[EPDTH]        FLOAT (53)   NULL, " +
                    "[FXDTH]        FLOAT (53)   NULL, " +
                    "[MXDTH]        FLOAT (53)   NULL, " +
                    "[PXDTH]        FLOAT (53)   NULL," +
                    "CONSTRAINT [PK_" + farm_outages + "] PRIMARY KEY CLUSTERED ([PK] ASC)) ", con);
                SqlDataReader myReader1 = cmd1.ExecuteReader();
                while (myReader1.Read()) { }
                myReader1.Close();

                SqlCommand cmd2 = new SqlCommand("CREATE TABLE [dbo].[" + farm_performance + "] ( " +
                    "[PK]          INT          IDENTITY (1, 1) NOT NULL, " +
                    "[UtilityID]   NCHAR (10)   NULL, " +
                    "[PlantIDName] VARCHAR (50) NULL, " +
                    "[GroupIDName] VARCHAR (50) NULL, " +
                    "[SubGroupID]  VARCHAR (50) NULL, " +
                    "[ReptMonth]   INT          NULL, " +
                    "[ReptYear]    INT          NULL, " +
                    "[SGStatus]    VARCHAR (50) NULL, " +
                    "[GAG]         FLOAT (53)   NULL, " +
                    "[NAG]         FLOAT (53)   NULL, " +
                    "[NMC]         FLOAT (53)   NULL, " +
                    "[PDTH]        FLOAT (53)   NULL, " +
                    "[CTH]         FLOAT (53)   NULL, " +
                    "[RSTH]        FLOAT (53)   NULL, " +
                    "[FTH]         FLOAT (53)   NULL, " +
                    "[MTH]         FLOAT (53)   NULL, " +
                    "[PTH]         FLOAT (53)   NULL, " +
                    "[OFTH]        FLOAT (53)   NULL, " +
                    "[OMTH]        FLOAT (53)   NULL, " +
                    "[OPTH]        FLOAT (53)   NULL," +
                    "[RUTH]        FLOAT (53)   NULL," +
                    "[IRTH]        FLOAT (53)   NULL," +
                    "[MBTH]        FLOAT (53)   NULL," +
                    "[RTH]         FLOAT (53)   NULL," +
                    "[EFDTH]       FLOAT (53)   NULL," +
                    "[EMDTH]       FLOAT (53)   NULL," +
                    "[EPDTH]       FLOAT (53)   NULL," +
                    "[OEFDTH]       FLOAT (53)   NULL," +
                    "[OEMDTH]       FLOAT (53)   NULL," +
                    "[OEPDTH]      FLOAT (53)   NULL," +
                    "[ERSDTH]      FLOAT (53)   NULL," +
                    "[FXDTH]       FLOAT (53)   NULL," +
                    "[MXDTH]       FLOAT (53)   NULL, " +
                    "[PXDTH]       FLOAT (53)   NULL, " +
                    "CONSTRAINT [PK_" + farm_performance + "] PRIMARY KEY CLUSTERED ([PK] ASC))", con);
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read()) { }
                myReader2.Close();

                SqlCommand cmd3 = new SqlCommand("CREATE TABLE [dbo].[" + farm_SubGroup + "] (" +
                    "[PK]                INT          IDENTITY (1, 1) NOT NULL," +
                    "[UtilityID]         NCHAR (10)   NULL," +
                    "[Region]            INT          NULL," +
                    "[PlantIDName]       VARCHAR (50) NULL," +
                    "[GroupIDName]       VARCHAR (50) NULL," +
                    "[SubGroupID]        VARCHAR (50) NULL," +
                    "[SubGroupName]      VARCHAR (50) NULL," +
                    "[ISOID]             VARCHAR (50) NULL, " +
                    "[Country]           VARCHAR (50) NULL, " +
                    "[NearCity]          VARCHAR (50) NULL, " +
                    "[State]             VARCHAR (50) NULL, " +
                    "[Latitude]         FLOAT (53)   NULL, " +
                    "[Longitude]         FLOAT (53)   NULL, " +
                    "[Elevation]         INT          NULL, " +
                    "[WRegime]          INT          NULL, " +
                    "[AAWS]              FLOAT (53)   NULL, " +
                    "[SCADAMfr]          VARCHAR (50) NULL, " +
                    "[SCADAMdl]          VARCHAR (50) NULL," +
                    "[CommYear]          INT          NULL," +
                    "[TotInstCapacity]   FLOAT (53)   NULL," +
                    "[RsrvCapacity]      FLOAT (53)   NULL," +
                    "[TurbineCount]      INT          NULL, " +
                    "[SystemMW]          FLOAT (53)   NULL, " +
                    "[MaxTurbineCap]     FLOAT (53)   NULL, " +
                    "[TurbineMfr]        VARCHAR (50) NULL, " +
                    "[TurbineMdl]        VARCHAR (50) NULL, " +
                    "[TurbineMdlVer]     VARCHAR (50) NULL, " +
                    "[RotorHeight]       FLOAT (53)   NULL, " +
                    "[RotorDiam]         FLOAT (53)   NULL, " +
                    "[CutinSpd]          FLOAT (53)   NULL, " +
                    "[LowCutoutSpd]      FLOAT (53)   NULL, " +
                    "[HighCutoutSpd]     FLOAT (53)   NULL, " +
                    "[TurbIntensity]     FLOAT (53)   NULL, " +
                    "[AvgWindSpd]        FLOAT (53)   NULL, " +
                    "[WindShear]         INT          NULL, " +
                    "[ReferenceAnemom]   INT          NULL, " +
                    "[MinOpTemp]         FLOAT (53)   NULL, " +
                    "[MaxOpTemp]         FLOAT (53)   NULL, " +
                    "[SubGrpOwnStatus]   VARCHAR (50) NULL," +
                    "[StatusEffDate]     DATE         NULL," +
                    "[TransfertoUtility] VARCHAR (50) NULL," +
                    "CONSTRAINT [PK_" + farm_SubGroup + "] PRIMARY KEY CLUSTERED ([PK] ASC))", con);
                SqlDataReader myReader3 = cmd3.ExecuteReader();
                while (myReader3.Read()) { }
                myReader3.Close();

                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Performance'", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString().Split('_')[0]);

                }
                comboBox3.DataSource = listp;

                MessageBox.Show("succeed");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button10_Click(object sender, EventArgs e)//all the 14 calculations(string name) to generate the 14 tables 
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                string farmName = textBox_farm.Text;
                string Outages = farmName + "_Outages";
                string Performance = farmName + "_Performance";
                string SubGroup = farmName + "_SubGroup";

               /* SqlDataAdapter sda = new SqlDataAdapter("select TotInstCapacity, TurbineCount, SystemMW from "+SubGroup+"", con);
                DataTable tableCheck1 = new DataTable();
                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                double a = tableCheck1.Rows[0].Field<double>(0);
                int b = tableCheck1.Rows[0].Field<int>(1);
                double c = tableCheck1.Rows[0].Field<double>(2);
                sda.Fill(tableCheck1);*/





                string SuperOutages = farmName + "_SuperOutages";
                string Wind_Farm_Summary_Category = farmName + "_Wind_Farm_Summary_Category";
                string Wind_Farm_Summary_Code = farmName + "_Wind_Farm_Summary_Code";

                string Summary_MW = farmName + "_Summary_MW";
                string Summary_MW_Category_Month = farmName + "_Summary_perMW_Category_Month";
                string Summary_MW_Category_Year = farmName + "_Summary_perMW_Category_Year";
                string Summary_MW_Avg_Yealy_1 = farmName + "_Summary_perMW_Avg_Yearly_1";
                string Summary_MW_Avg_Yealy_2 = farmName + "_Summary_perMW_Avg_Yearly_2";
                string Summary_MW_Avg_Monthly = farmName + "_Summary_perMW_Avg_Monthly";

                string Summary_Turbine = farmName + "_Summary_Turbine";
                string Summary_Turbine_Category_Month = farmName + "_Summary_perTurbine_Category_Month";
                string Summary_Turbine_Category_Year = farmName + "_Summary_perTurbine_Category_Year";
                string Summary_Turbine_Avg_Yealy_1 = farmName + "_Summary_perTurbine_Avg_Yearly_1";
                string Summary_Turbine_Avg_Yealy_2 = farmName + "_Summary_perTurbine_Avg_Yearly_2";
                string Summary_Turbine_Avg_Monthly = farmName + "_Summary_perTurbine_Avg_Monthly";
                string Summary_Monthly_Total = farmName + "_Summary_Monthly_Total";
                string Summary_Monthly_Total2 = farmName + "_Summary_Monthly_Total2";


                if (1==1)//tableCheck1.Rows[0].Field<double>(0) == tableCheck1.Rows[0].Field<int>(1) * tableCheck1.Rows[0].Field<double>(2))
                {

                    SqlCommand cmd = new SqlCommand("CREATE VIEW "+SuperOutages+" as" +
                        " select * from ["+Outages+"] a " +
                        "inner join [Sys-Com Codes] b " +
                        "on a.SysCompCode = b.Entry ", con);
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("CREATE VIEW "+Wind_Farm_Summary_Category+" AS " +
                        "select b.System, " +
                        "ISNULL(sum(FTH)*1.0,0) as FTH, " +
                        "ISNULL(sum(ForcedCount)*1.0,0) as ForcedCount, " +
                        "ISNULL(sum(MTH)*1.0,0) as MTH, " +
                        "ISNULL(sum(MaintCount)*1.0,0) as  MaintCount, " +
                        "ISNULL(sum(PTH)*1.0,0) as PTH, " +
                        "ISNULL(sum(PlannedCount)*1.0,0) as PlannedCount " +
                        "from "+Outages+" a " +
                        "inner join [Sys-Com Codes] b " +
                        "on a.SysCompCode = b.Entry " +
                        "group by b.System", con);
                    SqlDataReader myReader1 = cmd1.ExecuteReader();
                    while (myReader1.Read()) { }
                    myReader1.Close();

                    SqlCommand cmd2 = new SqlCommand("CREATE VIEW "+Wind_Farm_Summary_Code+" AS " +
                        "select SysCompCode, " +
                        "sum(FTH)*1.0 as FTH, " +
                        "sum(ForcedCount)*1.0 as ForcedCount, " +
                        "sum(MTH)*1.0 as MTH, " +
                        "sum(MaintCount)*1.0 as  MaintCount, " +
                        "sum(PTH)*1.0 as PTH, " +
                        "sum(PlannedCount)*1.0 as PlannedCount " +
                        "from "+Outages+" " +
                        "GROUP BY SysCompCode", con);
                    SqlDataReader myReader2 = cmd2.ExecuteReader();
                    while (myReader2.Read()) { }
                    myReader2.Close();


                    SqlCommand cmd3 = new SqlCommand("CREATE VIEW "+Summary_MW+" AS " +
                        "select SysCompCode," +
                        "FTH*1.0/TotInstCapacity as FTH, " +
                        "ForcedCount*1.0/TotInstCapacity as ForcedCount, " +
                        "MTH*1.0/TotInstCapacity as MTH, " +
                        "MaintCount*1.0/TotInstCapacity as  MaintCount, " +
                        "PTH*1.0/TotInstCapacity as PTH, " +
                        "PlannedCount*1.0/TotInstCapacity as PlannedCount " +
                        "from "+Outages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID", con);
                    SqlDataReader myReader3 = cmd3.ExecuteReader();
                    while (myReader3.Read()) { }
                    myReader3.Close();

                    SqlCommand cmd4 = new SqlCommand("CREATE VIEW "+Summary_MW_Category_Month+" as " +
                        "SELECT a.SubGroupID as SubGroupID," +
                        "a.ReptMonth as ReptMonth, " +
                        "a.System as System, " +
                        "sum(FTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as FTH, " +
                        "sum(ForcedCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as ForcedCount, " +
                        "sum(MTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as MTH, " +
                        "sum(MaintCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as  MaintCount, " +
                        "sum(PTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as PTH, " +
                        "sum(PlannedCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as PlannedCount " +
                        "FROM "+SuperOutages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID " +
                        "GROUP BY a.SubGroupID, a.ReptMonth, a.System", con);
                    SqlDataReader myReader4 = cmd4.ExecuteReader();
                    while (myReader4.Read()) { }
                    myReader4.Close();

                    SqlCommand cmd5 = new SqlCommand("CREATE VIEW "+Summary_MW_Category_Year+" as " +
                        "SELECT a.SubGroupID as SubGroupID, " +
                        "a.System as System, " +
                        "sum(FTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as FTH, " +
                        "sum(ForcedCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as ForcedCount, " +
                        "sum(MTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as MTH, " +
                        "sum(MaintCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as  MaintCount, " +
                        "sum(PTH)*1.0*count(TurbineCount)/sum(TotInstCapacity) as PTH, " +
                        "sum(PlannedCount)*1.0*count(TurbineCount)/sum(TotInstCapacity) as PlannedCount " +
                        "FROM "+SuperOutages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID " +
                        "GROUP BY a.System, a.SubGroupID", con);
                    SqlDataReader myReader5 = cmd5.ExecuteReader();
                    while (myReader5.Read()) { }
                    myReader5.Close();

                    SqlCommand cmd6 = new SqlCommand("CREATE VIEW "+Summary_MW_Avg_Yealy_1+" AS " +
                        "select System, " +
                        "CONVERT(DECIMAL(10,4),FTH/(select sum(TotInstCapacity) from "+SubGroup+")) as FTH, " +
                        "CONVERT(DECIMAL(10,4),ForcedCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+")) as ForcedCount, " +
                        "CONVERT(DECIMAL(10,4),MTH/(select sum(TotInstCapacity) from "+SubGroup+")) as MTH, " +
                        "CONVERT(DECIMAL(10,4),MaintCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+")) as MaintCount, " +
                        "CONVERT(DECIMAL(10,4),PTH/(select sum(TotInstCapacity) from "+SubGroup+")) as PTH, " +
                        "CONVERT(DECIMAL(10,4),PlannedCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+")) as PlannedCount, " +
                        "CONVERT(DECIMAL(10,5),FTH/(select sum(TotInstCapacity) from "+SubGroup+")+MTH/(select sum(TotInstCapacity) from "+SubGroup+")+PTH/(select sum(TotInstCapacity) from "+SubGroup+")) as TotalHrs, " +
                        "CONVERT(DECIMAL(10,5),ForcedCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+ ")+MaintCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+ ")+PlannedCount*1.0/(select sum(TotInstCapacity) from " + SubGroup+")) TotalCount " +
                        "from "+Wind_Farm_Summary_Category+"", con);
                    SqlDataReader myReader6 = cmd6.ExecuteReader();
                    while (myReader6.Read()) { }
                    myReader6.Close();

                    SqlCommand cmd7 = new SqlCommand("CREATE VIEW "+Summary_MW_Avg_Yealy_2+" AS " +
                        "select * , " +
                        "CONVERT(DECIMAL(10,4),TotalHrs/(select sum(TotalHrs) from " + Summary_MW_Avg_Yealy_1+" group by ())) as PercentHrs, " +
                        "CONVERT(DECIMAL(10,4),TotalCount/(select sum(TotalCount) from " + Summary_MW_Avg_Yealy_1+" group by ())) as PercentCount " +
                        "from "+Summary_MW_Avg_Yealy_1+"", con);
                    SqlDataReader myReader7 = cmd7.ExecuteReader();
                    while (myReader7.Read()) { }
                    myReader7.Close();

                    SqlCommand cmd8 = new SqlCommand("CREATE VIEW "+Summary_MW_Avg_Monthly+" AS " +
                        "select System," +
                        "CONVERT(DECIMAL(10,4),FTH/12) as FTH," +
                        "CONVERT(DECIMAL(10,4),ForcedCount/12) as ForcedCount," +
                        "CONVERT(DECIMAL(10,4),MTH/12) as MTH," +
                        "CONVERT(DECIMAL(10,4),MaintCount/12) as MaintCount," +
                        "CONVERT(DECIMAL(10,4),PTH/12) as PTH," +
                        "CONVERT(DECIMAL(10,4),PlannedCount/12) as PlannedCount," +
                        "CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs," +
                        "CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount," +
                        "PercentHrs," +
                        "PercentCount " +
                        "from "+Summary_MW_Avg_Yealy_2+"", con);
                    SqlDataReader myReader8 = cmd8.ExecuteReader();
                    while (myReader8.Read()) { }
                    myReader8.Close();

                    SqlCommand cmd9 = new SqlCommand("CREATE VIEW "+Summary_Turbine+" AS " +
                        "select SysCompCode, " +
                        "FTH/TurbineCount as FTH, " +
                        "CONVERT(DECIMAL(10,4),ForcedCount*1.0/TurbineCount) as ForcedCount, " +
                        "MTH/TurbineCount as MTH, " +
                        "CONVERT(DECIMAL(10,4),MaintCount*1.0/TurbineCount) as  MaintCount, " +
                        "PTH/TurbineCount as PTH, " +
                        "CONVERT(DECIMAL(10,4),PlannedCount*1.0/TurbineCount) as PlannedCount " +
                        "from "+Outages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID", con);
                    SqlDataReader myReader9 = cmd9.ExecuteReader();
                    while (myReader9.Read()) { }
                    myReader9.Close();

                    SqlCommand cmd10 = new SqlCommand("CREATE VIEW "+Summary_Turbine_Category_Month+" as " +
                        "SELECT a.SubGroupID as SubGroupID," +
                        "a.ReptMonth as ReptMonth, " +
                        "a.System as System, " +
                        "sum(FTH)*count(TurbineCount)/sum(TurbineCount) as FTH, " +
                        "CONVERT(DECIMAL(10,4),sum(ForcedCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as ForcedCount, " +
                        "sum(MTH)*count(TurbineCount)/sum(TurbineCount) as MTH, " +
                        "CONVERT(DECIMAL(10,4),sum(MaintCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as  MaintCount, " +
                        "sum(PTH)*count(TurbineCount)/sum(TurbineCount) as PTH, " +
                        "CONVERT(DECIMAL(10,4),sum(PlannedCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as PlannedCount " +
                        "FROM "+SuperOutages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID " +
                        "GROUP BY a.SubGroupID, a.ReptMonth, a.System", con);
                    SqlDataReader myReader10 = cmd10.ExecuteReader();
                    while (myReader10.Read()) { }
                    myReader10.Close();

                    SqlCommand cmd11 = new SqlCommand("CREATE VIEW "+Summary_Turbine_Category_Year+" as " +
                        "SELECT a.SubGroupID as SubGroupID, " +
                        "a.System as System, " +
                        "sum(FTH)*count(TurbineCount)/sum(TurbineCount) as FTH, " +
                        "CONVERT(DECIMAL(10,4),sum(ForcedCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as ForcedCount, " +
                        "sum(MTH)*count(TurbineCount)/sum(TurbineCount) as MTH, " +
                        "CONVERT(DECIMAL(10,4),sum(MaintCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as  MaintCount, " +
                        "sum(PTH)*count(TurbineCount)/sum(TurbineCount) as PTH, " +
                        "CONVERT(DECIMAL(10,4),sum(PlannedCount)*count(TurbineCount)*1.0/sum(TurbineCount)) as PlannedCount " +
                        "FROM "+SuperOutages+" a " +
                        "left join "+SubGroup+" b " +
                        "on a.SubGroupID = b.SubGroupID " +
                        "GROUP BY a.System, a.SubGroupID", con);
                    SqlDataReader myReader11 = cmd11.ExecuteReader();
                    while (myReader11.Read()) { }
                    myReader11.Close();

                    SqlCommand cmd12 = new SqlCommand("CREATE VIEW "+Summary_Turbine_Avg_Yealy_1+" AS " +
                        "select System, " +
                        "CONVERT(DECIMAL(10,4),FTH/(select sum(TurbineCount) from " + SubGroup + ")) as FTH, " +
                        "CONVERT(DECIMAL(10,4),ForcedCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")) as ForcedCount, " +
                        "CONVERT(DECIMAL(10,4),MTH/(select sum(TurbineCount) from " + SubGroup + ")) as MTH, " +
                        "CONVERT(DECIMAL(10,4),MaintCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")) as MaintCount, " +
                        "CONVERT(DECIMAL(10,4),PTH/(select sum(TurbineCount) from " + SubGroup + ")) as PTH, " +
                        "CONVERT(DECIMAL(10,4),PlannedCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")) as PlannedCount, " +
                        "CONVERT(DECIMAL(10,5),FTH/(select sum(TurbineCount) from " + SubGroup + ")+MTH/(select sum(TurbineCount) from " + SubGroup + ")+PTH/(select sum(TurbineCount) from " + SubGroup + ")) as TotalHrs, " +
                        "CONVERT(DECIMAL(10,5),ForcedCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")+MaintCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")+PlannedCount*1.0/(select sum(TurbineCount) from " + SubGroup + ")) TotalCount " +
                        "from " + Wind_Farm_Summary_Category + "", con);
                    SqlDataReader myReader12 = cmd12.ExecuteReader();
                    while (myReader12.Read()) { }
                    myReader12.Close();

                    SqlCommand cmd13 = new SqlCommand("CREATE VIEW "+Summary_Turbine_Avg_Yealy_2+" AS " +
                        "select * , " +
                        "CONVERT(DECIMAL(10,4),TotalHrs/(select sum(TotalHrs) from " + Summary_Turbine_Avg_Yealy_1+" group by ())) as PercentHrs, " +
                        "CONVERT(DECIMAL(10,4),TotalCount/(select sum(TotalCount) from " + Summary_Turbine_Avg_Yealy_1+" group by ())) as PercentCount " +
                        "from "+Summary_Turbine_Avg_Yealy_1+"", con);
                    SqlDataReader myReader13 = cmd13.ExecuteReader();
                    while (myReader13.Read()) { }
                    myReader13.Close();

                    SqlCommand cmd14 = new SqlCommand("CREATE VIEW "+Summary_Turbine_Avg_Monthly+" AS " +
                        "select System," +
                        "CONVERT(DECIMAL(10,4),FTH/12) as FTH," +
                        "CONVERT(DECIMAL(10,4),ForcedCount/12) as ForcedCount," +
                        "CONVERT(DECIMAL(10,4),MTH/12) as MTH," +
                        "CONVERT(DECIMAL(10,4),MaintCount/12) as MaintCount," +
                        "CONVERT(DECIMAL(10,4),PTH/12) as PTH," +
                        "CONVERT(DECIMAL(10,4),PlannedCount/12) as PlannedCount," +
                        "CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs," +
                        "CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount," +
                        "PercentHrs," +
                        "PercentCount " +
                        "from "+Summary_Turbine_Avg_Yealy_2+"", con);
                    SqlDataReader myReader14 = cmd14.ExecuteReader();
                    while (myReader14.Read()) { }
                    myReader14.Close();

                    SqlCommand cmd15 = new SqlCommand("CREATE VIEW "+Summary_Monthly_Total+" as " +
                        "select System," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 1 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Jan," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 2 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Feb," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 3 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Mar," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 4 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Apr," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 5 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) May," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 6 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Jun," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 7 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Jul," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 8 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Aug," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 9 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Sep," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 10 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Oct," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 11 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Nov," +
                        "CONVERT(DECIMAL(10,1),isnull(sum(case when ReptMonth = 12 then ISNULL(FTH,0)+ISNULL(MTH,0)+ISNULL(PTH,0) end), 0)) Dec " +
                        "from "+Summary_Turbine_Category_Month+" " +
                        "group by System", con);
                    SqlDataReader myReader15 = cmd15.ExecuteReader();
                    while (myReader15.Read()) { }
                    myReader15.Close();

                    SqlCommand cmd16 = new SqlCommand("CREATE VIEW "+Summary_Monthly_Total2+" as " +
                        "select System," +
                        "Jan*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Jan, " +
                        "Feb*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Feb, " +
                        "Mar*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Mar, " +
                        "Apr*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Apr, " +
                        "May*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as May, " +
                        "Jun*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Jun, " +
                        "Jul*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Jul, " +
                        "Aug*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Aug, " +
                        "Sep*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Sep, " +
                        "Oct*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Oct, " +
                        "Nov*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Nov, " +
                        "Dec*(select sum(TurbineCount)/count(TurbineCount) from "+SubGroup+") as Dec " +
                        "from "+Summary_Monthly_Total+"", con);
                    SqlDataReader myReader16 = cmd16.ExecuteReader();
                    while (myReader16.Read()) { }
                    myReader16.Close();

                    MessageBox.Show("succeed");
                    con.Close();
                }
                else
                {
                   /* con.Close();
                    MessageBox.Show("TotInstCapacity = " + a.ToString() + " , TurbineCount = " + b.ToString() + " , SystemMW = " + c.ToString() + " are incorrect");
                    Form5 f5 = new Form5();
                    f5.ShowDialog();*/
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }
        private void ExportDataTableToPdf1(DataSet dtblTable, String strPdfPath, String strPdfPath2, string strHeader)
        {
            System.IO.FileStream fs = new FileStream(strPdfPath, FileMode.Create, FileAccess.Write, FileShare.None);
            Document document = new Document();
            document.SetPageSize(iTextSharp.text.PageSize.A3);
            PdfWriter writer = PdfWriter.GetInstance(document, fs);
            document.Open();

            System.IO.FileStream fs2 = new FileStream(strPdfPath2, FileMode.Create, FileAccess.Write, FileShare.None);
            Document document2 = new Document();
            document2.SetPageSize(iTextSharp.text.PageSize.A3);
            PdfWriter writer2 = PdfWriter.GetInstance(document2, fs2);
            document2.Open();

            //REPORT HEADER
            BaseFont bfntHead = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font fntHead = new iTextSharp.text.Font(bfntHead, 10, 2);
            Paragraph prgHeading = new Paragraph();
            prgHeading.Alignment = Element.ALIGN_CENTER;
            prgHeading.Add(new Chunk(strHeader, fntHead));
            document.Add(prgHeading);

            //Author
            Paragraph prgAuthor = new Paragraph();
            BaseFont btnAuthor = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font fntAuthor = new iTextSharp.text.Font(btnAuthor, 8, 2);
            prgAuthor.Alignment = Element.ALIGN_RIGHT;
            prgAuthor.Add(new Chunk("Author: WEICan", fntAuthor));
            prgAuthor.Add(new Chunk("\nRun Date: " + DateTime.Now.ToShortDateString(), fntAuthor));
            document.Add(prgAuthor);
            
            //add a line seperation
            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, iTextSharp.text.BaseColor.BLUE, Element.ALIGN_LEFT, 0.0F)));
            document.Add(p);
            //add line break
            document.Add(new Chunk("\n", fntHead));

            string farmName = textBox_farm.Text;
          
            string n0 = farmName + "_Wind_Farm_Summary_Category";
            string n1 = farmName + "_Wind_Farm_Summary_Code";

            string n2 = farmName + "_Summary_MW";
            string n3 = farmName + "_Summary_perMW_Category_Month";
            string n4 = farmName + "_Summary_perMW_Category_Year";
            
            string n5 = farmName + "_Summary_perMW_Avg_Yearly";
            string n6 = farmName + "_Summary_perMW_Avg_Monthly";

            string n7 = farmName + "_Summary_Turbine";
            string n8 = farmName + "_Summary_perTurbine_Category_Month";
            string n9 = farmName + "_Summary_perTurbine_Category_Year";
            
            string n10 = farmName + "_Summary_perTurbine_Avg_Yearly";
            string n11 = farmName + "_Summary_perTurbine_Avg_Monthly";
            string n12 = farmName + "_Summary_Monthly_Total";

            string[] nn = new string[13];
            nn[0] = n0; nn[1] = n1; nn[2] = n2; nn[3] = n3; nn[4] = n4; nn[5] = n5; nn[6] = n6;
            nn[7] = n7; nn[8] = n8; nn[9] = n9; nn[10] = n10; nn[11] = n11; nn[12] = n12;

            document.Add(new Chunk("GADS description", fntHead));
            document.Add(new Chunk("\n", fntHead));
            //part4 begins
            for (int i = 0; i < 11; i++)
            {


                PdfPTable table = ExportDataTableToPdf2(dataSet8.Tables[i]);

                document.Add(table);


            }
            for (int i = 0; i < 22; i++)
            {
                
                
                PdfPTable table = ExportDataTableToPdf2(dataSet7.Tables[i]);

                document.Add(table);
                
                
            }
            document.Add(new Chunk("\n", fntHead));
            
            document.Add(new Chunk("\n", fntHead));
            //part four ended
            //part2 starts
            for (int i = 0; i< 13; i++)
            {
                document2.Add(new Chunk(nn[i], fntHead));
                document2.Add(new Chunk("\n", fntHead));
                PdfPTable table = ExportDataTableToPdf2(dtblTable.Tables[i]);

                document2.Add(table);
                //add a line seperation
                Paragraph p1 = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, iTextSharp.text.BaseColor.GRAY, Element.ALIGN_LEFT, 0.0F)));
                document2.Add(p1);
                document2.Add(new Chunk("\n", fntHead));
            }
            //part2 ends
            //part3 starts
            var chartimage7 = new MemoryStream();
            chart7.SaveImage(chartimage7, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image7 = iTextSharp.text.Image.GetInstance(chartimage7.GetBuffer());
            document.Add(Chart_image7);

            var chartimage10 = new MemoryStream();
            chart10.SaveImage(chartimage10, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image10 = iTextSharp.text.Image.GetInstance(chartimage10.GetBuffer());
            document.Add(Chart_image10);

            var chartimage1 = new MemoryStream();
            chart1.SaveImage(chartimage1, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image1 = iTextSharp.text.Image.GetInstance(chartimage1.GetBuffer());
            document.Add(Chart_image1);

            var chartimage2 = new MemoryStream();
            chart2.SaveImage(chartimage2, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image2 = iTextSharp.text.Image.GetInstance(chartimage2.GetBuffer());
            document.Add(Chart_image2);

            var chartimage5 = new MemoryStream();
            chart5.SaveImage(chartimage5, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image5 = iTextSharp.text.Image.GetInstance(chartimage5.GetBuffer());
            document.Add(Chart_image5);

            var chartimage4= new MemoryStream();
            chart4.SaveImage(chartimage4, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image4 = iTextSharp.text.Image.GetInstance(chartimage4.GetBuffer());
            document.Add(Chart_image4);

            var chartimage3 = new MemoryStream();
            chart3.SaveImage(chartimage3, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image3 = iTextSharp.text.Image.GetInstance(chartimage3.GetBuffer());
            document.Add(Chart_image3);

            var chartimage6 = new MemoryStream();
            chart6.SaveImage(chartimage6, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image6 = iTextSharp.text.Image.GetInstance(chartimage6.GetBuffer());
            document.Add(Chart_image6);

            var chartimage8 = new MemoryStream();
            chart8.SaveImage(chartimage8, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image8 = iTextSharp.text.Image.GetInstance(chartimage8.GetBuffer());
            document.Add(Chart_image8);

            var chartimage9 = new MemoryStream();
            chart9.SaveImage(chartimage9, ChartImageFormat.Jpeg);
            iTextSharp.text.Image Chart_image9 = iTextSharp.text.Image.GetInstance(chartimage9.GetBuffer());
            document.Add(Chart_image9);
            //part3 ends
            document.Close();
            writer.Close();
            fs.Close();

            document2.Close();
            writer2.Close();
            fs2.Close();

        }

        private PdfPTable ExportDataTableToPdf2(DataTable dtblTable)
        { 

            //write the table

            PdfPTable table = new PdfPTable(dtblTable.Columns.Count);
            //table header
            BaseFont btnColumnHeader = BaseFont.CreateFont(BaseFont.TIMES_ROMAN,BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font fntColumnHeader = new iTextSharp.text.Font(btnColumnHeader,12,1, BaseColor.WHITE);

            for(int i = 0; i < dtblTable.Columns.Count; i++)
            {
                PdfPCell cell = new PdfPCell();
                cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                cell.AddElement(new Chunk(dtblTable.Columns[i].ColumnName,fntColumnHeader));
                table.AddCell(cell);
            }
            //table Data
            for(int i =0; i< dtblTable.Rows.Count; i++)
            {
                for(int j  = 0; j < dtblTable.Columns.Count; j++)
                {
                    table.AddCell(dtblTable.Rows[i][j].ToString());
                }
            }
            return table;


            
        }

        private void button11_Click(object sender, EventArgs e)

        /*Print to PDF function
       Function operates in three parts.
       Part 1: Select All 14 active tables for each farm,  Copy data to dataset5. Save output of all files to
                Debug PDF.
       Part 2:  Save output of all (14) files to
                Debug PDF..
       Part 3: Call function(arguments, ath) to gather charts for farm <farm_name>. Save to <farm_name>.pdf
       part 4: copy and paste the GADs Description to PDF
       
        */


        {
            string farmName = textBox_farm.Text;
            string SuperOutages = farmName + "_SuperOutages";
            string Wind_Farm_Summary_Category = farmName + "_Wind_Farm_Summary_Category";
            string Wind_Farm_Summary_Code = farmName + "_Wind_Farm_Summary_Code";

            string Summary_MW = farmName + "_Summary_MW";
            string Summary_MW_Category_Month = farmName + "_Summary_perMW_Category_Month";
            string Summary_MW_Category_Year = farmName + "_Summary_perMW_Category_Year";
            string Summary_MW_Avg_Yealy_1 = farmName + "_Summary_perMW_Avg_Yearly_1";
            string Summary_MW_Avg_Yealy_2 = farmName + "_Summary_perMW_Avg_Yearly_2";
            string Summary_MW_Avg_Monthly = farmName + "_Summary_perMW_Avg_Monthly";

            string Summary_Turbine = farmName + "_Summary_Turbine";
            string Summary_Turbine_Category_Month = farmName + "_Summary_perTurbine_Category_Month";
            string Summary_Turbine_Category_Year = farmName + "_Summary_perTurbine_Category_Year";
            string Summary_Turbine_Avg_Yealy_1 = farmName + "_Summary_perTurbine_Avg_Yearly_1";
            string Summary_Turbine_Avg_Yealy_2 = farmName + "_Summary_perTurbine_Avg_Yearly_2";
            string Summary_Turbine_Avg_Monthly = farmName + "_Summary_perTurbine_Avg_Monthly";
            string Summary_Monthly_Total = farmName + "_Summary_Monthly_Total2";

            //Start Part 1
            try
            {
                
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();



                

                SqlDataAdapter myDataAdapter = new SqlDataAdapter("select * from " + Wind_Farm_Summary_Category, con);
                System.Data.DataTable dt = new System.Data.DataTable();
                myDataAdapter.Fill(dt);
                dataSet5.Tables.Add(dt);

                SqlDataAdapter myDataAdapter2 = new SqlDataAdapter("select * from " + Wind_Farm_Summary_Code, con);
                System.Data.DataTable dt2 = new System.Data.DataTable();
                myDataAdapter2.Fill(dt2);
                dataSet5.Tables.Add(dt2);

                SqlDataAdapter myDataAdapter3 = new SqlDataAdapter("select * from " + Summary_MW, con);
                System.Data.DataTable dt3 = new System.Data.DataTable();
                myDataAdapter3.Fill(dt3);
                dataSet5.Tables.Add(dt3);

                SqlDataAdapter myDataAdapter4 = new SqlDataAdapter("select * from " + Summary_MW_Category_Month, con);
                System.Data.DataTable dt4 = new System.Data.DataTable();
                myDataAdapter4.Fill(dt4);
                dataSet5.Tables.Add(dt4);

                SqlDataAdapter myDataAdapter5 = new SqlDataAdapter("select * from " + Summary_MW_Category_Year, con);
                System.Data.DataTable dt5 = new System.Data.DataTable();
                myDataAdapter5.Fill(dt5);
                dataSet5.Tables.Add(dt5);

                SqlDataAdapter myDataAdapter6 = new SqlDataAdapter("select * from " + Summary_MW_Avg_Yealy_2, con);
                System.Data.DataTable dt6 = new System.Data.DataTable();
                myDataAdapter6.Fill(dt6);
                dataSet5.Tables.Add(dt6);

                SqlDataAdapter myDataAdapter7 = new SqlDataAdapter("select * from " + Summary_MW_Avg_Monthly, con);
                System.Data.DataTable dt7 = new System.Data.DataTable();
                myDataAdapter7.Fill(dt7);
                dataSet5.Tables.Add(dt7);

                SqlDataAdapter myDataAdapter8 = new SqlDataAdapter("select * from " + Summary_Turbine, con);
                System.Data.DataTable dt8 = new System.Data.DataTable();
                myDataAdapter8.Fill(dt8);
                dataSet5.Tables.Add(dt8);

                SqlDataAdapter myDataAdapter9 = new SqlDataAdapter("select * from " + Summary_Turbine_Category_Month, con);
                System.Data.DataTable dt9 = new System.Data.DataTable();
                myDataAdapter9.Fill(dt9);
                dataSet5.Tables.Add(dt9);

                SqlDataAdapter myDataAdapter10 = new SqlDataAdapter("select * from " + Summary_Turbine_Category_Year, con);
                System.Data.DataTable dt10 = new System.Data.DataTable();
                myDataAdapter10.Fill(dt10);
                dataSet5.Tables.Add(dt10);

                SqlDataAdapter myDataAdapter11 = new SqlDataAdapter("select * from " + Summary_Turbine_Avg_Yealy_2, con);
                System.Data.DataTable dt11 = new System.Data.DataTable();
                myDataAdapter11.Fill(dt11);
                dataSet5.Tables.Add(dt11);

                SqlDataAdapter myDataAdapter12 = new SqlDataAdapter("select * from " + Summary_Turbine_Avg_Monthly, con);
                System.Data.DataTable dt12 = new System.Data.DataTable();
                myDataAdapter12.Fill(dt12);
                dataSet5.Tables.Add(dt12);

                SqlDataAdapter myDataAdapter13 = new SqlDataAdapter("select * from " + Summary_Monthly_Total, con);
                System.Data.DataTable dt13 = new System.Data.DataTable();
                myDataAdapter13.Fill(dt13);
                dataSet5.Tables.Add(dt13);

                //End Part 1



                //Start Part 2
                string value = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
                string value2 = value.Split('=')[2];
                string value3 = value2.Split(';')[0];
                label7.Text = value3;
                String strPdfPath = "W:\\Projects\\5032 - GADS\\Reports\\"+farmName+"_" + DateTime.Now.ToShortDateString()+ ".pdf";
                String strPdfPath2 = "W:\\Projects\\5032 - GADS\\Reports\\" + farmName + "_" + DateTime.Now.ToShortDateString() + "_debug.pdf";
                String strHeader = farmName + "_Report";
                //+value3+"\\"
                ExportDataTableToPdf1(dataSet5, strPdfPath, strPdfPath2, strHeader);

                con.Close();
                MessageBox.Show("succeed" );
            }



            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void button12_Click(object sender, EventArgs e)//define and generate GADS description and 10 other charts
        {

            try
            {

                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                string farmName = textBox_farm.Text;
                string SuperOutages = farmName + "_SuperOutages";
                string Wind_Farm_Summary_Category = farmName + "_Wind_Farm_Summary_Category";
                string Wind_Farm_Summary_Code = farmName + "_Wind_Farm_Summary_Code";
                string Summary_MW = farmName + "_Summary_MW";
                string Summary_MW_Category_Month = farmName + "_Summary_perMW_Category_Month";
                string Summary_MW_Category_Year = farmName + "_Summary_perMW_Category_Year";
                string Summary_MW_Avg_Yealy_1 = farmName + "_Summary_perMW_Avg_Yearly_1";
                string Summary_MW_Avg_Yealy_2 = farmName + "_Summary_perMW_Avg_Yearly_2";

                string Summary_MW_Avg_Monthly = farmName + "_Summary_perMW_Avg_Monthly";
                string Summary_Turbine = farmName + "_Summary_Turbine";
                string Summary_Turbine_Category_Month = farmName + "_Summary_perTurbine_Category_Month";
                string Summary_Turbine_Category_Year = farmName + "_Summary_perTurbine_Category_Year";
                string Summary_Turbine_Avg_Yealy_1 = farmName + "_Summary_perTurbine_Avg_Yearly_1";
                string Summary_Turbine_Avg_Yealy_2 = farmName + "_Summary_perTurbine_Avg_Yearly_2";
                string Summary_Turbine_Avg_Monthly = farmName + "_Summary_perTurbine_Avg_Monthly";
                string Summary_Monthly_Total = farmName + "_Summary_Monthly_Total2";

                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Outages'", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString().Split('_')[0]);

                }
                if (listp.Contains(textBox_farm.Text))
                {
                    //part 1: GADS description
                    List<String> listGADs = new List<string>();
                    listGADs.Add("GAG");
                    listGADs.Add("NAG");
                    listGADs.Add("NMC");
                    listGADs.Add("PDTH");
                    listGADs.Add("CTH");
                    listGADs.Add("RSTH");
                    listGADs.Add("FTH");
                    listGADs.Add("MTH");
                    listGADs.Add("PTH");
                    listGADs.Add("OFTH");
                    listGADs.Add("OMTH");
                    listGADs.Add("OPTH");
                    listGADs.Add("RUTH");
                    listGADs.Add("IRTH");
                    listGADs.Add("MBTH");
                    listGADs.Add("RTH");

                    List<String> listGADs2 = new List<string>();
                    listGADs2.Add("CommYear");
                    listGADs2.Add("SystemMW");
                    listGADs2.Add("TurbineCount");
                    //listGADs2.Add("TurbineMfr");
                    //listGADs2.Add("TurbineMdl");
                    listGADs2.Add("RotorHeight");
                    listGADs2.Add("RotorDiam");
                    listGADs2.Add("CutinSpd");
                    listGADs2.Add("LowCutoutSpd");
                    listGADs2.Add("HighCutoutSpd");
                    listGADs2.Add("TurbIntensity");
                    listGADs2.Add("AvgWindSpd");
                    listGADs2.Add("WindShear");

                    foreach (String GAG in listGADs2)
                    {
                        String subQu1 = "select " + farmName + ".Site as Site,";
                        string subQu2 = " CONVERT(DECIMAL(10,1),(" + farmName + ".Site*(select sum(TurbineCount) from " + farmName + "_SubGroup) ";

                        string subQu3 = "((select sum(TurbineCount) from " + farmName + "_SubGroup) ";
                        string subQu4 = farmName + "_" + GAG + " " + farmName + " ";


                        foreach (String Name in listp)
                        {
                            string CMDv = "CREATE VIEW " + Name + "_" + GAG + " AS select " + GAG + " AS Site from " + Name + "_SubGroup ";
                            SqlCommand cm00 = new SqlCommand(CMDv, con);
                            cm00.ExecuteNonQuery();
                            //MessageBox.Show(CMDv);
                            if (Name != farmName)
                            {
                                subQu2 += "+" + Name + ".Site*(select sum(TurbineCount) from " + Name + "_SubGroup) ";
                                subQu3 += "+(select sum(TurbineCount) from " + Name + "_SubGroup) ";
                                subQu4 += ", " + Name + "_" + GAG + " " + Name + " ";
                            }
                        }

                        subQu2 += ")/";
                        subQu3 += ")) as Average from ";
                        string subQu5 = subQu1 + subQu2 + subQu3 + subQu4;

                        SqlDataAdapter myDA = new SqlDataAdapter(subQu5, con);
                        System.Data.DataTable DataT = new System.Data.DataTable();
                        myDA.Fill(DataT);
                        if (GAG == "TurbineCount")
                        {
                            String subQu11 = "select " + farmName + ".Site as Site,";
                            string subQu21 = " (" + farmName + ".Site ";

                            string subQu31 = "( " + listp.Count();
                            string subQu41 = farmName + "_" + GAG + " " + farmName + " ";
                            foreach (String Name in listp)
                            {


                                if (Name != farmName)
                                {
                                    subQu21 += "+" + Name + ".Site ";
                                    subQu31 += " ";
                                    subQu41 += ", " + Name + "_" + GAG + " " + Name + " ";
                                }
                            }
                            subQu21 += ")/";
                            subQu31 += ") as Average from ";
                            string subQu51 = subQu1 + subQu2 + subQu3 + subQu4;

                            SqlDataAdapter myDA11 = new SqlDataAdapter(subQu51, con);
                            System.Data.DataTable DataT11 = new System.Data.DataTable();
                            myDA11.Fill(DataT11);
                            DataT = DataT11;

                        }


                        DataT.Columns[0].ColumnName = "Site(" + GAG + ") ";
                        DataT.Columns[1].ColumnName = "Weighted Canadian Average ";
                        dataSet8.Tables.Add(DataT);



                        foreach (String Name in listp)
                        {
                            string Qdelete = "drop VIEW " + Name + "_" + GAG + " ";
                            SqlCommand cmd1 = new SqlCommand(Qdelete, con);
                            cmd1.ExecuteNonQuery();
                        }
                    }


                    var list = new string[] { "IRTH", "MBTH", "RTH" };
                    foreach (String GAG in listGADs)
                    {

                        String subQu1 = "select " + farmName + ".Site/(select sum(TotInstCapacity) from " + farmName + "_SubGroup) as Site,";
                        String subQu2 = "";
                        if (list.Contains(GAG))
                        {
                            subQu2 = " (" + farmName + ".Site ";
                        }
                        else
                        {
                            subQu2 = " (" + farmName + ".Site ";
                        }
                        string subQu3 = "((select sum(TotInstCapacity) from " + farmName + "_SubGroup) ";
                        string subQu4 = farmName + "_" + GAG + " " + farmName + " ";


                        foreach (String Name in listp)
                        {
                            SqlCommand cm00 = new SqlCommand("CREATE VIEW " + Name + "_" + GAG + " AS select sum(" + GAG + ") AS Site from " + Name + "_Performance ", con);
                            cm00.ExecuteNonQuery();

                            if (Name != farmName)
                            {
                                subQu2 += "+" + Name + ".Site ";
                                subQu3 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup) ";
                                subQu4 += ", " + Name + "_" + GAG + " " + Name + " ";
                            }
                        }

                        subQu2 += ")/";
                        if (list.Contains(GAG))
                        {
                            subQu3 += ")*1.0 as Average from ";
                        }
                        else
                        {
                            subQu3 += ")*1.0 as Average from ";
                        }
                        string subQu5 = subQu1 + subQu2 + subQu3 + subQu4;

                        SqlDataAdapter myDA = new SqlDataAdapter(subQu5, con);
                        System.Data.DataTable DataT = new System.Data.DataTable();
                        myDA.Fill(DataT);
                        if (GAG == "NMC")
                        {
                            SqlDataAdapter myDA2 = new SqlDataAdapter("select sum(NMC)/count(distinct(ReptMonth)) from " + farmName + "_Performance", con);
                            System.Data.DataTable DataTa = new System.Data.DataTable();
                            myDA2.Fill(DataTa);
                            DataT.Rows[0][0] = (double)DataTa.Rows[0][0];


                            //select (WEICan.Site/(select sum(NMC) from WEICan_Performance) + TechnoCenter.Site/(select sum(NMC) from TechnoCenter_Performance))/2 as Average from WEICan_NMC WEICan, TechnoCenter_NMC TechnoCenter

                            string subQu21 = "select (" + farmName + ".Site/(select count(distinct(ReptMonth)) from " + farmName + "_Performance) ";


                            string subQu41 = farmName + "_" + GAG + " " + farmName + " ";


                            foreach (String Name in listp)
                            {
                                if (Name != farmName)
                                {
                                    subQu21 += "+" + Name + ".Site/(select count(distinct(ReptMonth)) from " + Name + "_Performance) ";

                                    subQu41 += ", " + Name + "_" + GAG + " " + Name + " ";
                                }
                            }

                            subQu21 += ")/" + listp.Count() + " as Average from ";

                            string subQu51 = subQu21 + subQu41;

                            SqlDataAdapter myDA4 = new SqlDataAdapter(subQu51, con);
                            System.Data.DataTable DataTa3 = new System.Data.DataTable();
                            myDA4.Fill(DataTa3);
                            DataT.Rows[0][1] = (double)DataTa3.Rows[0][0];

                        }

                        //DataT.Columns["Site"].Caption = "Site(" + GAG + ")";
                        if (GAG == "GAG" || GAG == "NAG")
                        {
                            DataT.Columns[0].ColumnName = "Site(" + GAG + ")  MWh/MW";
                        }
                        else if (GAG == "NMC")
                        {
                            DataT.Columns[0].ColumnName = "Site(" + GAG + ")  MW";
                        }
                        else
                        {
                            DataT.Columns[0].ColumnName = "Site(" + GAG + ")  Hours/MW";
                        }
                        DataT.Columns[1].ColumnName = "Weighted Canadian Average ";
                        dataSet7.Tables.Add(DataT);



                        /*foreach (String Name in listp)
                        {
                            string Qdelete = "drop VIEW " + Name + "_" + GAG + " ";
                            SqlCommand cmd1 = new SqlCommand(Qdelete, con);
                            cmd1.ExecuteNonQuery();
                        }*/
                    }



                    System.Data.DataTable DataT1 = new System.Data.DataTable();
                    DataT1.Columns.Add("Site(SATH)  Hours/MW", typeof(float));
                    DataT1.Columns.Add("Weighted Canadian Average", typeof(float));
                    double val1 = (double)dataSet7.Tables[3].Rows[0][0] - (double)dataSet7.Tables[12].Rows[0][0];
                    double val2 = (double)dataSet7.Tables[3].Rows[0][1] - (double)dataSet7.Tables[12].Rows[0][1];
                    DataT1.Rows.Add(val1, val2);
                    dataSet7.Tables.Add(DataT1);

                    System.Data.DataTable DataT2 = new System.Data.DataTable();
                    DataT2.Columns.Add("Site(SUTH)  Hours/MW", typeof(float));
                    DataT2.Columns.Add("Weighted Canadian Average", typeof(float));
                    double val3 = (double)dataSet7.Tables[6].Rows[0][0] + (double)dataSet7.Tables[7].Rows[0][0] + (double)dataSet7.Tables[8].Rows[0][0] + (double)dataSet7.Tables[12].Rows[0][0];
                    double val4 = (double)dataSet7.Tables[6].Rows[0][1] + (double)dataSet7.Tables[7].Rows[0][1] + (double)dataSet7.Tables[8].Rows[0][1] + (double)dataSet7.Tables[12].Rows[0][1];
                    DataT2.Rows.Add(val3, val4);
                    dataSet7.Tables.Add(DataT2);

                    System.Data.DataTable DataT3 = new System.Data.DataTable();
                    DataT3.Columns.Add("Site(EATH)  Hours/MW", typeof(float));
                    DataT3.Columns.Add("Weighted Canadian Average", typeof(float));
                    double val5 = (double)dataSet7.Tables[4].Rows[0][0] + (double)dataSet7.Tables[12].Rows[0][0];
                    double val6 = (double)dataSet7.Tables[4].Rows[0][1] + (double)dataSet7.Tables[12].Rows[0][1];
                    DataT3.Rows.Add(val5, val6);
                    dataSet7.Tables.Add(DataT3);

                    System.Data.DataTable DataT4 = new System.Data.DataTable();
                    DataT4.Columns.Add("Site(EUTH)  Hours/MW", typeof(float));
                    DataT4.Columns.Add("Weighted Canadian Average", typeof(float));
                    double val7 = (double)dataSet7.Tables[6].Rows[0][0] + (double)dataSet7.Tables[7].Rows[0][0] + (double)dataSet7.Tables[8].Rows[0][0];
                    double val8 = (double)dataSet7.Tables[6].Rows[0][1] + (double)dataSet7.Tables[7].Rows[0][1] + (double)dataSet7.Tables[8].Rows[0][1];
                    DataT4.Rows.Add(val7, val8);
                    dataSet7.Tables.Add(DataT4);

                    /*string Q3 = "CREATE VIEW " + Name + "_capacity AS select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(isnull(TotInstCapacity,0)/isnull(TurbineCount,0))/count(isnull(SystemMW,0)) from " + Name + "_SubGroup)) as " + Name + "_capacity FROM " + Name + "_Performance";
                        SqlCommand cmd3 = new SqlCommand(Q3, con);
                        cmd3.ExecuteNonQuery();*/

                    SqlDataAdapter myDA3 = new SqlDataAdapter("select sum(ISNULL(NAG, 0)) / (SUM(isnull(PDTH, 0)) * (select sum(isnull(TotInstCapacity, 0) / isnull(TurbineCount, 0))/count(isnull(TotInstCapacity,0))  from " + farmName + "_SubGroup))  FROM " + farmName + "_Performance", con);
                    System.Data.DataTable DataTa2 = new System.Data.DataTable();
                    myDA3.Fill(DataTa2);
                    System.Data.DataTable DataT5 = new System.Data.DataTable();

                    string subQ1 = "select (" + farmName + "_NAG.Site / " + farmName + "_PDTH.Site * (select sum(turbineCount)/count(turbineCount) from " + farmName + "_SubGroup) ";
                    string subQ2 = "(select sum(TotInstCapacity)/count(TotInstCapacity) from " + farmName + "_SubGroup)";
                    string subQ3 = ") from " + farmName + "_NAG, " + farmName + "_PDTH ";
                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            subQ1 += " + " + Name + "_NAG.Site/" + Name + "_PDTH.Site*(select sum(turbineCount)/count(turbineCount) from " + Name + "_SubGroup) ";
                            subQ2 += "+(select sum(TotInstCapacity)/count(TotInstCapacity) from " + Name + "_SubGroup)";
                            subQ3 += ", " + Name + "_NAG, " + Name + "_PDTH";
                        }
                    }
                    subQ1 += ")/(";
                    string subQ4 = subQ1 + subQ2 + subQ3;
                    SqlDataAdapter myDA5 = new SqlDataAdapter(subQ4, con);
                    System.Data.DataTable DataTa4 = new System.Data.DataTable();
                    myDA5.Fill(DataTa4);


                    DataT5.Columns.Add("Site(RNCF)  %", typeof(float));
                    DataT5.Columns.Add("Average", typeof(float));
                    double val9 = (double)DataTa2.Rows[0][0];
                    //double val9 = (double)dataSet7.Tables[1].Rows[0][0] / ((double)dataSet7.Tables[3].Rows[0][0] * (double)dataSet7.Tables[2].Rows[0][0]);
                    double val10 = (double)DataTa4.Rows[0][0];
                    //double val10 = (double)dataSet7.Tables[1].Rows[0][1] / ((double)dataSet7.Tables[3].Rows[0][1] * (double)dataSet7.Tables[2].Rows[0][1]);
                    DataT5.Rows.Add(val9 * 100, val10 * 100);
                    dataSet7.Tables.Add(DataT5);


                    System.Data.DataTable DataT6 = new System.Data.DataTable();
                    DataT6.Columns.Add("Site(EEAF)  %", typeof(float));
                    DataT6.Columns.Add("Average", typeof(float));
                    double val11 = ((double)dataSet7.Tables[3].Rows[0][0] - ((double)dataSet7.Tables[6].Rows[0][0] + (double)dataSet7.Tables[7].Rows[0][0] + (double)dataSet7.Tables[8].Rows[0][0])) / (double)dataSet7.Tables[3].Rows[0][0];
                    double val12 = ((double)dataSet7.Tables[3].Rows[0][1] - ((double)dataSet7.Tables[6].Rows[0][1] + (double)dataSet7.Tables[7].Rows[0][1] + (double)dataSet7.Tables[8].Rows[0][1])) / (double)dataSet7.Tables[3].Rows[0][1];
                    DataT6.Rows.Add(val11 * 100, val12 * 100);
                    dataSet7.Tables.Add(DataT6);

                    foreach (String GAG in listGADs)
                    {
                        foreach (String Name in listp)
                        {
                            string Qdelete = "drop VIEW " + Name + "_" + GAG + " ";
                            SqlCommand cmd1 = new SqlCommand(Qdelete, con);
                            cmd1.ExecuteNonQuery();
                        }
                    }
                    //end of the part1
                    //part2 : create the sourse tables for the charts
                    SqlDataAdapter myDataAdapter = new SqlDataAdapter("select a.System, b.PercentHrs as oneFarm, a.PercentHrs as allFarm " +
                            "from master_Summary_MW_Avg_Monthly a " +
                            "full join " + Summary_MW_Avg_Monthly + " b " +
                            "on a.System = b.System", con);
                    System.Data.DataTable dt = new System.Data.DataTable();
                    myDataAdapter.Fill(dt);
                    dataSet6.Tables.Add(dt);

                    //CONVERT(DECIMAL(10,2),FTH/12)
                    SqlDataAdapter myDataAdapter2 = new SqlDataAdapter("select a.System, b.PercentCount as oneFarm, a.PercentCount as allFarm " +
                        "from master_Summary_MW_Avg_Monthly a " +
                        "full join " + Summary_MW_Avg_Monthly + " b " +
                        "on a.System = b.System", con);
                    System.Data.DataTable dt2 = new System.Data.DataTable();
                    myDataAdapter2.Fill(dt2);
                    dataSet6.Tables.Add(dt2);

                    SqlDataAdapter myDataAdapter3 = new SqlDataAdapter("select a.System, b.PercentHrs as oneFarm, a.PercentHrs as allFarm " +
                        "from master_Summary_Turbine_Avg_Monthly a " +
                        "full join " + Summary_Turbine_Avg_Monthly + " b " +
                        "on a.System = b.System", con);
                    System.Data.DataTable dt3 = new System.Data.DataTable();
                    myDataAdapter3.Fill(dt3);
                    dataSet6.Tables.Add(dt3);

                    SqlDataAdapter myDataAdapter4 = new SqlDataAdapter("select a.System, b.PercentCount as oneFarm, a.PercentCount as allFarm " +
                        "from master_Summary_Turbine_Avg_Monthly a " +
                        "full join " + Summary_Turbine_Avg_Monthly + " b " +
                        "on a.System = b.System", con);
                    System.Data.DataTable dt4 = new System.Data.DataTable();
                    myDataAdapter4.Fill(dt4);
                    dataSet6.Tables.Add(dt4);





                    string subQuery1 = "select a.System, a.TotalHrs as AverageHrs, a.TotalCount AS AverageCount ";
                    string subQuery2 = "from master_Summary_MW_Avg_Yearly2 a ";
                    foreach (String Name in listp)
                    {
                        subQuery1 += ", isnull(" + Name + ".TotalHrs,0) as " + Name + "Hrs, isnull(" + Name + ".TotalCount,0) as " + Name + "Count ";
                        subQuery2 += "full join " + Name + "_Summary_perMW_Avg_Yearly_2 " + Name + " " +
                            "on a.System = " + Name + ".System ";
                    }
                    string subQuery3 = subQuery1 + subQuery2;
                    SqlDataAdapter myDataAdapter7 = new SqlDataAdapter(subQuery3, con);
                    System.Data.DataTable dt7 = new System.Data.DataTable();
                    myDataAdapter7.Fill(dt7);
                    dataSet6.Tables.Add(dt7);


                    string subQuery4 = "select a.System, a.TotalHrs as AverageHrs, a.TotalCount AS AverageCount ";
                    string subQuery5 = "from master_Summary_Turbine_Avg_Yearly2 a ";
                    foreach (String Name in listp)
                    {
                        subQuery4 += ", isnull(" + Name + ".TotalHrs,0) as " + Name + "Hrs, isnull(" + Name + ".TotalCount,0) as " + Name + "Count ";
                        subQuery5 += "full join " + Name + "_Summary_perTurbine_Avg_Yearly_2 " + Name + " " +
                            "on a.System = " + Name + ".System ";
                    }
                    string subQuery6 = subQuery4 + subQuery5;


                    SqlDataAdapter myDataAdapter8 = new SqlDataAdapter(subQuery6, con);
                    System.Data.DataTable dt8 = new System.Data.DataTable();
                    myDataAdapter8.Fill(dt8);
                    dataSet6.Tables.Add(dt8);
                    //end of part two

                    /*SqlDataAdapter myDataAdapter5 = new SqlDataAdapter("select Field , (select avg(Field) from Availablity2) as Average from Availablity2", con);
                    System.Data.DataTable dt5 = new System.Data.DataTable();
                    myDataAdapter5.Fill(dt5);
                    dataSet6.Tables.Add(dt5);

                    SqlDataAdapter myDataAdapter6 = new SqlDataAdapter("select Field , (select avg(Field) from Capacity2) as Average from Capacity2", con);
                    System.Data.DataTable dt6 = new System.Data.DataTable();
                    myDataAdapter6.Fill(dt6);
                    dataSet6.Tables.Add(dt6);

                    string Q11 = "drop VIEW TechnoCenter_Availablity ";
                    SqlCommand cmd1 = new SqlCommand(Q11, con);
                    cmd1.ExecuteNonQuery();

                    string Q21 = "drop VIEW WEICan_Availablity ";
                    SqlCommand cmd21 = new SqlCommand(Q21, con);
                    cmd21.ExecuteNonQuery();

                    string Q31 = "drop VIEW TechnoCenter_capacity ";
                    SqlCommand cmd31 = new SqlCommand(Q31, con);
                    cmd31.ExecuteNonQuery();

                    string Q41 = "drop VIEW WEICan_capacity ";
                    SqlCommand cmd41 = new SqlCommand(Q41, con);
                    cmd41.ExecuteNonQuery();

                    string Q51 = "drop VIEW Availablity ";
                    SqlCommand cmd51 = new SqlCommand(Q51, con);
                    cmd51.ExecuteNonQuery();

                    string Q61 = "drop VIEW Capacity ";
                    SqlCommand cmd61 = new SqlCommand(Q61, con);
                    cmd61.ExecuteNonQuery();
                    string Q71 = "drop VIEW Availablity2 ";
                    SqlCommand cmd71 = new SqlCommand(Q71, con);
                    cmd71.ExecuteNonQuery();

                    string Q81 = "drop VIEW Capacity2 ";
                    SqlCommand cmd81 = new SqlCommand(Q81, con);
                    cmd81.ExecuteNonQuery();*/

                    //part three define and show all the charts

                    chart1.Titles.Add("Figure 3: Downtime Hours Per MW");
                    chart1.Legends["Legend1"].Docking = Docking.Bottom;
                    chart1.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart1.ChartAreas["ChartArea1"].AxisY.Title = "Proportion";

                    chart1.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart1.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Horizontal;
                    chart1.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart1.Series.Add(farmName);
                    chart1.Series[farmName].ChartType = SeriesChartType.Bar;
                    chart1.Series[farmName].ChartArea = "ChartArea1";
                    chart1.Series[farmName].Label = "#PERCENT";
                    chart1.Series[farmName].YValueMembers = "oneFarm";
                    chart1.Series[farmName].XValueMember = "System";



                    chart1.Series["Average"].Label = "#PERCENT";
                    chart1.Series["Average"].ChartType = SeriesChartType.Bar;
                    chart1.Series["Average"].XValueMember = "System";
                    chart1.Series["Average"].YValueMembers = "allFarm";
                    chart1.Series["Average"].Color = Color.Gray;


                    chart1.DataSource = dataSet6.Tables[0];
                    chart1.DataBind();






                    chart2.Titles.Add("Figure 4: Downtime Occurences Per MW");
                    chart2.Legends["Legend1"].Docking = Docking.Bottom;
                    chart2.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart2.ChartAreas["ChartArea1"].AxisY.Title = "Proportion";

                    chart2.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart2.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Horizontal;
                    chart2.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart2.Series.Add(farmName);
                    chart2.Series[farmName].ChartType = SeriesChartType.Bar;
                    chart2.Series[farmName].ChartArea = "ChartArea1";
                    chart2.Series[farmName].Label = "#PERCENT";
                    chart2.Series[farmName].YValueMembers = "oneFarm";
                    chart2.Series[farmName].XValueMember = "System";

                    chart2.Series["Average"].Label = "#PERCENT";
                    chart2.Series["Average"].ChartType = SeriesChartType.Bar;
                    chart2.Series["Average"].XValueMember = "System";
                    chart2.Series["Average"].YValueMembers = "allFarm";
                    chart2.Series["Average"].Color = Color.Gray;

                    chart2.DataSource = dataSet6.Tables[1];
                    chart2.DataBind();



                    chart5.Titles.Add("Figure 5: Downtime Hours Per Turbine");
                    chart5.Legends["Legend1"].Docking = Docking.Bottom;
                    chart5.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart5.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart5.ChartAreas["ChartArea1"].AxisY.Title = "Proportion";

                    chart5.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart5.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Horizontal;
                    chart5.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart5.Series.Add(farmName);
                    chart5.Series[farmName].ChartType = SeriesChartType.Bar;
                    chart5.Series[farmName].ChartArea = "ChartArea1";
                    chart5.Series[farmName].Label = "#PERCENT";
                    chart5.Series[farmName].YValueMembers = "oneFarm";
                    chart5.Series[farmName].XValueMember = "System";



                    chart5.Series["Average"].Label = "#PERCENT";
                    chart5.Series["Average"].ChartType = SeriesChartType.Bar;
                    chart5.Series["Average"].XValueMember = "System";
                    chart5.Series["Average"].YValueMembers = "allFarm";
                    chart5.Series["Average"].Color = Color.Gray;

                    chart5.DataSource = dataSet6.Tables[2];
                    chart5.DataBind();



                    chart4.Titles.Add("Figure 6: Downtime Occurences Per Turbine");
                    chart4.Legends["Legend1"].Docking = Docking.Bottom;
                    chart4.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart4.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart4.ChartAreas["ChartArea1"].AxisY.Title = "Proportion";

                    chart4.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart4.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Horizontal;
                    chart4.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart4.Series.Add(farmName);
                    chart4.Series[farmName].ChartType = SeriesChartType.Bar;
                    chart4.Series[farmName].ChartArea = "ChartArea1";
                    chart4.Series[farmName].Label = "#PERCENT";
                    chart4.Series[farmName].YValueMembers = "oneFarm";
                    chart4.Series[farmName].XValueMember = "System";

                    chart4.Series["Average"].Label = "#PERCENT";
                    chart4.Series["Average"].ChartType = SeriesChartType.Bar;
                    chart4.Series["Average"].XValueMember = "System";
                    chart4.Series["Average"].YValueMembers = "allFarm";
                    chart4.Series["Average"].Color = Color.Gray;


                    chart4.DataSource = dataSet6.Tables[3];
                    chart4.DataBind();






                    chart3.Legends["Legend1"].Docking = Docking.Bottom;
                    chart3.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart3.Titles.Add("Figure 7: Downtime Hours Per MW");
                    chart3.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart3.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular);

                    /*chart3.ChartAreas["ChartArea1"].AxisX.Title = "System";

                    chart3.ChartAreas["ChartArea1"].AxisX.TitleAlignment = StringAlignment.Center;

                    chart3.ChartAreas["ChartArea1"].AxisX.TextOrientation = TextOrientation.Horizontal;*/

                    chart3.ChartAreas["ChartArea1"].AxisY.Title = "Hours Per MW";

                    chart3.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart3.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;



                    chart3.Series["Average"].ChartType = SeriesChartType.Point;
                    //chart2.Series["Average"].Label = "#PERCENT";
                    chart3.Series["Average"].XValueMember = "System";
                    // chart3.Series["Average"].Font = new System.Drawing.Font("Arial", 20);
                    chart3.Series["Average"].YValueMembers = "AverageHrs";
                    chart3.Series["Average"].Color = Color.Green;
                    chart3.Series["Average"].MarkerColor = Color.DarkGreen;
                    chart3.Series["Average"].MarkerSize = 8;
                    chart3.Series["Average"].MarkerStyle = MarkerStyle.Cross;


                    chart3.Series.Add(farmName);
                    chart3.Series[farmName].ChartType = SeriesChartType.Point;
                    chart3.Series[farmName].ChartArea = "ChartArea1";
                    //chart2.Series["TechnoCenter"].Label = "#PERCENT";
                    chart3.Series[farmName].Color = Color.OrangeRed;
                    chart3.Series[farmName].XValueMember = "System";
                    chart3.Series[farmName].YValueMembers = farmName + "Hrs";
                    //chart3.Series[farmName].Font = new System.Drawing.Font("Arial", 20);
                    chart3.Series[farmName].MarkerColor = Color.OrangeRed;
                    chart3.Series[farmName].MarkerSize = 9;
                    chart3.Series[farmName].MarkerStyle = MarkerStyle.Triangle;
                    int NameCount = 0;
                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            NameCount++;
                            chart3.Series.Add("farm" + NameCount);
                            chart3.Series["farm" + NameCount].ChartType = SeriesChartType.Point;
                            chart3.Series["farm" + NameCount].ChartArea = "ChartArea1";
                            //chart2.Series["WEICan"].Label = "#PERCENT";
                            chart3.Series["farm" + NameCount].Color = Color.Gray;
                            chart3.Series["farm" + NameCount].XValueMember = "System";
                            chart3.Series["farm" + NameCount].YValueMembers = Name + "Hrs";
                            // chart3.Series["farm" + NameCount].Font = new System.Drawing.Font("Arial", 20);
                            chart3.Series["farm" + NameCount].MarkerColor = Color.Gray;
                            chart3.Series["farm" + NameCount].MarkerSize = 5;
                            chart3.Series["farm" + NameCount].MarkerStyle = MarkerStyle.Circle;
                        }
                    }
                    NameCount = 0;
                    chart3.DataSource = dataSet6.Tables[4];
                    chart3.DataBind();





                    chart6.Legends["Legend1"].Docking = Docking.Bottom;
                    chart6.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart6.Titles.Add("Figure 8: Downtime Occurences Per MW");
                    chart6.ChartAreas["ChartArea1"].AxisX.Interval = 1;


                    chart6.ChartAreas["ChartArea1"].AxisY.Title = "Occurences Per MW";

                    chart6.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart6.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;


                    chart6.Series["Average"].ChartType = SeriesChartType.Point;
                    //chart2.Series["Average"].Label = "#PERCENT";
                    chart6.Series["Average"].ChartArea = "ChartArea1";
                    chart6.Series["Average"].XValueMember = "System";
                    chart6.Series["Average"].YValueMembers = "AverageCount";
                    //chart6.Series["Average"].LegendText.
                    chart6.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular);
                    //chart6.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font.SizeInPoints(9F);
                    chart6.Series["Average"].Color = Color.Green;
                    chart6.Series["Average"].MarkerColor = Color.DarkGreen;
                    chart6.Series["Average"].MarkerSize = 8;
                    chart6.Series["Average"].MarkerStyle = MarkerStyle.Cross;


                    chart6.Series.Add(farmName);
                    chart6.Series[farmName].ChartType = SeriesChartType.Point;
                    chart6.Series[farmName].ChartArea = "ChartArea1";
                    //chart2.Series["TechnoCenter"].Label = "#PERCENT";
                    chart6.Series[farmName].Color = Color.OrangeRed;
                    chart6.Series[farmName].XValueMember = "System";
                    chart6.Series[farmName].YValueMembers = farmName + "Count";
                    chart6.Series[farmName].MarkerColor = Color.OrangeRed;
                    chart6.Series[farmName].MarkerSize = 9;
                    chart6.Series[farmName].MarkerStyle = MarkerStyle.Triangle;

                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            NameCount++;
                            chart6.Series.Add("farm" + NameCount);
                            chart6.Series["farm" + NameCount].ChartType = SeriesChartType.Point;
                            chart6.Series["farm" + NameCount].ChartArea = "ChartArea1";
                            //chart2.Series["WEICan"].Label = "#PERCENT";
                            chart6.Series["farm" + NameCount].Color = Color.Gray;
                            chart6.Series["farm" + NameCount].XValueMember = "System";
                            chart6.Series["farm" + NameCount].YValueMembers = Name + "Count";
                            chart6.Series["farm" + NameCount].MarkerColor = Color.Gray;
                            chart6.Series["farm" + NameCount].MarkerSize = 5;
                            chart6.Series["farm" + NameCount].MarkerStyle = MarkerStyle.Circle;
                        }
                    }
                    NameCount = 0;
                    chart6.DataSource = dataSet6.Tables[4];
                    chart6.DataBind();




                    chart8.Legends["Legend1"].Docking = Docking.Bottom;
                    chart8.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart8.Titles.Add("Figure 9: Downtime Hours Per Turbine");
                    chart8.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart8.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular);

                    chart8.ChartAreas["ChartArea1"].AxisY.Title = "Hours Per Turbine";

                    chart8.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart8.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;


                    chart8.Series["Average"].ChartType = SeriesChartType.Point;
                    //chart2.Series["Average"].Label = "#PERCENT";
                    chart8.Series["Average"].XValueMember = "System";
                    chart8.Series["Average"].YValueMembers = "AverageHrs";
                    chart8.Series["Average"].Color = Color.Green;
                    chart8.Series["Average"].MarkerColor = Color.DarkGreen;
                    chart8.Series["Average"].MarkerSize = 8;
                    chart8.Series["Average"].MarkerStyle = MarkerStyle.Cross;


                    chart8.Series.Add(farmName);
                    chart8.Series[farmName].ChartType = SeriesChartType.Point;
                    chart8.Series[farmName].ChartArea = "ChartArea1";
                    //chart2.Series["TechnoCenter"].Label = "#PERCENT";
                    chart8.Series[farmName].Color = Color.OrangeRed;
                    chart8.Series[farmName].XValueMember = "System";
                    chart8.Series[farmName].YValueMembers = farmName + "Hrs";
                    chart8.Series[farmName].MarkerColor = Color.OrangeRed;
                    chart8.Series[farmName].MarkerSize = 9;
                    chart8.Series[farmName].MarkerStyle = MarkerStyle.Triangle;

                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            NameCount++;
                            chart8.Series.Add("farm" + NameCount);
                            chart8.Series["farm" + NameCount].ChartType = SeriesChartType.Point;
                            chart8.Series["farm" + NameCount].ChartArea = "ChartArea1";
                            //chart2.Series["WEICan"].Label = "#PERCENT";
                            chart8.Series["farm" + NameCount].Color = Color.Gray;
                            chart8.Series["farm" + NameCount].XValueMember = "System";
                            chart8.Series["farm" + NameCount].YValueMembers = Name + "Hrs";
                            chart8.Series["farm" + NameCount].MarkerColor = Color.Gray;
                            chart8.Series["farm" + NameCount].MarkerSize = 5;
                            chart8.Series["farm" + NameCount].MarkerStyle = MarkerStyle.Circle;
                        }
                    }
                    NameCount = 0;
                    chart8.DataSource = dataSet6.Tables[5];
                    chart8.DataBind();




                    chart9.Legends["Legend1"].Docking = Docking.Bottom;
                    chart9.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart9.Titles.Add("Figure 10: Downtime Occurences Per Turbine");
                    chart9.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart9.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular);

                    chart9.ChartAreas["ChartArea1"].AxisY.Title = "Occurences Per Turbine";

                    chart9.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart9.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;

                    chart9.Series["Average"].ChartType = SeriesChartType.Point;
                    //chart2.Series["Average"].Label = "#PERCENT";
                    chart9.Series["Average"].XValueMember = "System";
                    chart9.Series["Average"].YValueMembers = "AverageCount";
                    chart9.Series["Average"].Color = Color.Green;
                    chart9.Series["Average"].MarkerColor = Color.DarkGreen;
                    chart9.Series["Average"].MarkerSize = 8;
                    chart9.Series["Average"].MarkerStyle = MarkerStyle.Cross;


                    chart9.Series.Add(farmName);
                    chart9.Series[farmName].ChartType = SeriesChartType.Point;
                    chart9.Series[farmName].ChartArea = "ChartArea1";
                    //chart2.Series["TechnoCenter"].Label = "#PERCENT";
                    chart9.Series[farmName].Color = Color.Red;
                    chart9.Series[farmName].XValueMember = "System";
                    chart9.Series[farmName].YValueMembers = farmName + "Count";
                    chart9.Series[farmName].MarkerColor = Color.Red;
                    chart9.Series[farmName].MarkerSize = 9;
                    chart9.Series[farmName].MarkerStyle = MarkerStyle.Triangle;

                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            NameCount++;
                            chart9.Series.Add("farm" + NameCount);
                            chart9.Series["farm" + NameCount].ChartType = SeriesChartType.Point;
                            chart9.Series["farm" + NameCount].ChartArea = "ChartArea1";
                            //chart2.Series["WEICan"].Label = "#PERCENT";
                            chart9.Series["farm" + NameCount].Color = Color.Gray;
                            chart9.Series["farm" + NameCount].XValueMember = "System";
                            chart9.Series["farm" + NameCount].YValueMembers = Name + "Count";
                            chart9.Series["farm" + NameCount].MarkerColor = Color.Gray;
                            chart9.Series["farm" + NameCount].MarkerSize = 5;
                            chart9.Series["farm" + NameCount].MarkerStyle = MarkerStyle.Circle;
                        }
                    }
                    NameCount = 0;
                    chart9.DataSource = dataSet6.Tables[5];
                    chart9.DataBind();


                    foreach (String Name in listp)
                    {
                        string Q1 = "CREATE VIEW " + Name + "_Availablity AS select(SUM(PDTH)-SUM(isnull(FTH, 0) + isnull(MTH, 0) + isnull(PTH, 0) + isnull(EFDTH, 0) + isnull(EMDTH, 0) + isnull(EPDTH, 0) ))/ SUM(PDTH) AS " + Name + "_Availablity from " + Name + "_Performance";
                        SqlCommand cmd = new SqlCommand(Q1, con);
                        cmd.ExecuteNonQuery();

                        /*string Q2 = "CREATE VIEW WEICan_Availablity AS select (SUM(CTH + RSTH + FTH + MTH + PTH + RUTH)-SUM(isnull(FTH,0) + isnull(MTH,0) + isnull(PTH,0) + isnull(EFDTH,0) + isnull(EMDTH,0) + isnull(EPDTH,0) + isnull(RUTH,0)))/SUM(CTH + RSTH + FTH + MTH + PTH + RUTH) AS WEICan_Availablity from Performance";
                        SqlCommand cmd2 = new SqlCommand(Q2, con);
                        cmd2.ExecuteNonQuery();*/

                        string Q3 = "CREATE VIEW " + Name + "_capacity AS select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(isnull(TotInstCapacity,0)/isnull(TurbineCount,0))/count(isnull(SystemMW,0)) from " + Name + "_SubGroup)) as " + Name + "_capacity FROM " + Name + "_Performance";
                        SqlCommand cmd3 = new SqlCommand(Q3, con);
                        cmd3.ExecuteNonQuery();

                        /*string Q4 = "CREATE VIEW WEICan_capacity AS select sum(ISNULL(NAG,0))/(SUM(isnull(PDTH,0)) * (select sum(SystemMW) from TechnoCenter_SubGroup)) as WEICan_capacity FROM Performance";
                        SqlCommand cmd4 = new SqlCommand(Q4, con);
                        cmd4.ExecuteNonQuery();*/
                    }
                    string ava = "CREATE VIEW Availablity AS select * from " + farmName + "_Availablity ";
                    string cap = "CREATE VIEW Capacity AS select * from " + farmName + "_capacity ";
                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            ava += ", " + Name + "_Availablity ";
                            cap += ", " + Name + "_capacity ";
                        }
                    }
                    string Q5 = ava;
                    SqlCommand cmd5 = new SqlCommand(Q5, con);
                    cmd5.ExecuteNonQuery();

                    string Q6 = cap;
                    SqlCommand cmd6 = new SqlCommand(Q6, con);
                    cmd6.ExecuteNonQuery();

                    string ava2 = "CREATE VIEW Availablity2 AS select Field from Availablity UNPIVOT (Field for ColumnName IN ([" + farmName + "_Availablity] ";
                    string cap2 = "CREATE VIEW Capacity2 AS select Field from Capacity UNPIVOT (Field for ColumnName IN ([" + farmName + "_capacity] ";
                    foreach (String Name in listp)
                    {
                        if (Name != farmName)
                        {
                            ava2 += ", [" + Name + "_Availablity] ";
                            cap2 += ", [" + Name + "_capacity] ";
                        }
                    }

                    ava2 += ")) unpvt";
                    cap2 += ")) unpvt";
                    string Q7 = ava2;
                    SqlCommand cmd7 = new SqlCommand(Q7, con);
                    cmd7.ExecuteNonQuery();

                    string Q8 = cap2;
                    SqlCommand cmd8 = new SqlCommand(Q8, con);
                    cmd8.ExecuteNonQuery();


                    SqlDataAdapter myDataAdapter5 = new SqlDataAdapter("select Field , (select avg(Field) from Availablity2) as Average from Availablity2", con);
                    System.Data.DataTable dt5 = new System.Data.DataTable();
                    myDataAdapter5.Fill(dt5);
                    dataSet6.Tables.Add(dt5);

                    SqlDataAdapter myDataAdapter6 = new SqlDataAdapter("select Field , (select avg(Field) from Capacity2) as Average from Capacity2", con);
                    System.Data.DataTable dt6 = new System.Data.DataTable();
                    myDataAdapter6.Fill(dt6);
                    dataSet6.Tables.Add(dt6);

                    foreach (String Name in listp)
                    {
                        string Q11 = "drop VIEW " + Name + "_Availablity ";
                        SqlCommand cmd1 = new SqlCommand(Q11, con);
                        cmd1.ExecuteNonQuery();

                        /*string Q21 = "drop VIEW WEICan_Availablity ";
                        SqlCommand cmd21 = new SqlCommand(Q21, con);
                        cmd21.ExecuteNonQuery();*/

                        string Q31 = "drop VIEW " + Name + "_capacity ";
                        SqlCommand cmd31 = new SqlCommand(Q31, con);
                        cmd31.ExecuteNonQuery();

                        /*string Q41 = "drop VIEW WEICan_capacity ";
                        SqlCommand cmd41 = new SqlCommand(Q41, con);
                        cmd41.ExecuteNonQuery();*/
                    }
                    string Q51 = "drop VIEW Availablity ";
                    SqlCommand cmd51 = new SqlCommand(Q51, con);
                    cmd51.ExecuteNonQuery();

                    string Q61 = "drop VIEW Capacity ";
                    SqlCommand cmd61 = new SqlCommand(Q61, con);
                    cmd61.ExecuteNonQuery();
                    string Q71 = "drop VIEW Availablity2 ";
                    SqlCommand cmd71 = new SqlCommand(Q71, con);
                    cmd71.ExecuteNonQuery();

                    string Q81 = "drop VIEW Capacity2 ";
                    SqlCommand cmd81 = new SqlCommand(Q81, con);
                    cmd81.ExecuteNonQuery();




                    chart7.Legends["Legend1"].Docking = Docking.Bottom;
                    chart7.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart7.Titles.Add("Figure 1: Resourse Net Capacity Factor");
                    chart7.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart7.ChartAreas["ChartArea1"].AxisX.Title = "Farm Number";

                    chart7.ChartAreas["ChartArea1"].AxisX.TitleAlignment = StringAlignment.Center;

                    chart7.ChartAreas["ChartArea1"].AxisX.TextOrientation = TextOrientation.Horizontal;

                    chart7.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart7.ChartAreas["ChartArea1"].AxisY.Title = "RNCF %";

                    chart7.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart7.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;


                    chart7.Series["Weighted average across all turbines"].ChartType = SeriesChartType.Line;
                    chart7.Series["Weighted average across all turbines"].YValueMembers = "Average";
                    chart7.Series["Weighted average across all turbines"].Color = Color.DarkGray;



                    chart7.Series.Add("data from other farms");
                    chart7.Series["data from other farms"].ChartType = SeriesChartType.Point;
                    chart7.Series["data from other farms"].ChartArea = "ChartArea1";
                    chart7.Series["data from other farms"].Color = Color.Black;
                    chart7.Series["data from other farms"].YValueMembers = "Field";
                    chart7.Series["data from other farms"].MarkerSize = 6;
                    chart7.Series["data from other farms"].MarkerStyle = MarkerStyle.Circle;

                    //(double)DataTa4.Rows[0][0];

                    System.Data.DataTable DataT8 = new System.Data.DataTable();
                    DataT8.Columns.Add("Field", typeof(float));
                    DataT8.Columns.Add("Average", typeof(float));
                    for (int n = 0; n < dataSet6.Tables[7].Rows.Count; n++)
                    {
                        double val15 = (double)dataSet6.Tables[7].Rows[n][0];

                        double val16 = (double)DataTa4.Rows[0][0];
                        DataT8.Rows.Add(val15, val16);
                    }

                    chart7.DataSource = DataT8;
                    //chart7.DataSource = dataSet6.Tables[7];
                    chart7.DataBind();
                    chart7.Series["data from other farms"].Points[0].Label = farmName;
                    chart7.Series["data from other farms"].Points[0].Color = Color.Red;





                    chart10.Legends["Legend1"].Docking = Docking.Bottom;
                    chart10.Legends["Legend1"].Alignment = StringAlignment.Center;
                    chart10.Titles.Add("Figure 2: Equipment Equivalent Avaialability Factor");
                    chart10.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                    chart10.ChartAreas["ChartArea1"].AxisX.Title = "Farm Number";

                    chart10.ChartAreas["ChartArea1"].AxisX.TitleAlignment = StringAlignment.Center;

                    chart10.ChartAreas["ChartArea1"].AxisX.TextOrientation = TextOrientation.Horizontal;

                    chart10.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:#0.##%}";

                    chart10.ChartAreas["ChartArea1"].AxisY.Title = "EEAF %";

                    chart10.ChartAreas["ChartArea1"].AxisY.TitleAlignment = StringAlignment.Center;

                    chart10.ChartAreas["ChartArea1"].AxisY.TextOrientation = TextOrientation.Auto;


                    chart10.Series["Weighted average across all turbines"].ChartType = SeriesChartType.Line;
                    chart10.Series["Weighted average across all turbines"].YValueMembers = "Average";
                    chart10.Series["Weighted average across all turbines"].Color = Color.DarkGray;
                    //chart3.Series["Weighted average across all turbines"].Points[0].Label = "TechnoCenter";



                    chart10.Series.Add("data from other farms");
                    chart10.Series["data from other farms"].ChartType = SeriesChartType.Point;
                    chart10.Series["data from other farms"].ChartArea = "ChartArea1";
                    chart10.Series["data from other farms"].Color = Color.Black;
                    chart10.Series["data from other farms"].YValueMembers = "Field";
                    chart10.Series["data from other farms"].MarkerSize = 6;
                    chart10.Series["data from other farms"].MarkerStyle = MarkerStyle.Circle;


                    System.Data.DataTable DataT7 = new System.Data.DataTable();
                    DataT7.Columns.Add("Field", typeof(float));
                    DataT7.Columns.Add("Average", typeof(float));
                    for (int n = 0; n < dataSet6.Tables[6].Rows.Count; n++)
                    {
                        double val13 = (double)dataSet6.Tables[6].Rows[n][0];
                        double val14 = ((double)dataSet7.Tables[3].Rows[0][1] - ((double)dataSet7.Tables[6].Rows[0][1] + (double)dataSet7.Tables[7].Rows[0][1] + (double)dataSet7.Tables[8].Rows[0][1])) / (double)dataSet7.Tables[3].Rows[0][1];
                        DataT7.Rows.Add(val13, val14);
                    }
                    chart10.DataSource = DataT7;




                    //chart10.DataSource = dataSet6.Tables[6];
                    chart10.DataBind();
                    chart10.Series["data from other farms"].Points[0].Label = farmName;
                    chart10.Series["data from other farms"].Points[0].Color = Color.Red;

                    //end of part 3

                    con.Close();
                    MessageBox.Show("succeed");
                }
                else
                {
                    con.Close();
                    MessageBox.Show("Invalid farm name, please make sure it is correct");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }


        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chart3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)// do the six master calculations and generate 6 master tables for all farms
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();


                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Outages'", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString().Split('_')[0]);

                }
                //string subQuery0 = "CREATE VIEW master_Summary_MW_Avg_Yearly_N AS select WEICan.System";

                string subQuery1 = "CREATE VIEW master_Summary_MW_Avg_Yearly_N AS select WEICan.System , CONVERT(DECIMAL(10,4),(isnull(WEICan.FTH,0)";
                string subQuery2 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";
                string subQuery3 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.ForcedCount*1.0,0)";
                string subQuery4 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";

                string subQuery5 = ", CONVERT(DECIMAL(10,4),(isnull(WEICan.MTH,0)";
                string subQuery6 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";
                string subQuery7 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.MaintCount*1.0,0)";
                string subQuery8 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";

                string subQuery9 = ", CONVERT(DECIMAL(10,4),(isnull(WEICan.PTH,0)";
                string subQuery10 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";
                string subQuery11 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.PlannedCount*1.0,0)";
                string subQuery12 = "((select sum(TotInstCapacity) from WEICan_SubGroup)";

                //string subQuery13 = ", CONVERT(DECIMAL(10,5),(isnull(WEICan.FTH,0)";

                string subQuery20 = "from WEICan_Wind_Farm_Summary_Category WEICan  ";

                foreach (String Name in listp)
                {
                    if (Name != "WEICan")
                    {
                        subQuery1 += "+isnull(" + Name + ".FTH,0)";
                        subQuery2 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";
                        subQuery3 += "+isnull(" + Name + ".ForcedCount*1.0,0)";
                        subQuery4 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";

                        subQuery5 += "+isnull(" + Name + ".MTH,0)";
                        subQuery6 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";
                        subQuery7 += "+isnull(" + Name + ".MaintCount*1.0,0)";
                        subQuery8 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";

                        subQuery9 += "+isnull(" + Name + ".PTH,0)";
                        subQuery10 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";
                        subQuery11 += "+isnull(" + Name + ".PlannedCount*1.0,0)";
                        subQuery12 += "+(select sum(TotInstCapacity) from " + Name + "_SubGroup)";

                        

                        subQuery20 += "full join " + Name + "_Wind_Farm_Summary_Category " + Name + " " +
                            "on WEICan.System = " + Name + ".System ";
                        
                    }
                }
                subQuery1 +=   ")/";
                subQuery2 +=  ")) as FTH ";
                subQuery3 +=  ")/";
                subQuery4 += ")) as ForcedCount ";

                subQuery5 += ")/";
                subQuery6 +=  ")) as MTH ";
                subQuery7 +=  ")/";
                subQuery8 += ")) as MaintCount ";

                subQuery9 +=  ")/";
                subQuery10 += ")) as PTH ";
                subQuery11 +=  ")/";
                subQuery12 +=  ")) as PlannedCount ";

                string subQuery21 = subQuery1 + subQuery2 + subQuery3 + subQuery4 + subQuery5 + subQuery6 + subQuery7 + subQuery8 + subQuery9 + subQuery10 + subQuery11 + subQuery12 + subQuery20;
               // MessageBox.Show("query: " + subQuery21);
                SqlCommand cmd0 = new SqlCommand(subQuery21, con);
                cmd0.ExecuteNonQuery();

                SqlCommand cmd = new SqlCommand("CREATE VIEW master_Summary_MW_Avg_Yearly2 AS " +
                    "select System, FTH, ForcedCount, MTH, MaintCount, PTH, PlannedCount, " +
                    "(FTH+MTH+PTH) AS TotalHrs, (ForcedCount+MaintCount+PlannedCount) AS TotalCount, " +
                    "CONVERT(DECIMAL(10,4),(FTH+MTH+PTH)*1.0/(select sum(FTH+MTH+PTH)*1.0 from master_Summary_MW_Avg_Yearly_N group by ())) as PercentHrs, " +
                    "CONVERT(DECIMAL(10,4),(ForcedCount+MaintCount+PlannedCount)*1.0/(select sum(ForcedCount+MaintCount+PlannedCount) from master_Summary_MW_Avg_Yearly_N group by ())) as PercentCount " +
                    "FROM master_Summary_MW_Avg_Yearly_N", con);
                cmd.ExecuteNonQuery();


                SqlCommand cmd2 = new SqlCommand("CREATE VIEW master_Summary_MW_Avg_Monthly AS " +
                    "select System, " +
                    "CONVERT(DECIMAL(10,4),FTH/12) as FTH, " +
                    "CONVERT(DECIMAL(10,4),ForcedCount/12) as ForcedCount, " +
                    "CONVERT(DECIMAL(10,4),MTH/12) as MTH, " +
                    "CONVERT(DECIMAL(10,4),MaintCount/12) as MaintCount, " +
                    "CONVERT(DECIMAL(10,4),PTH/12) as PTH, " +
                    "CONVERT(DECIMAL(10,4),PlannedCount/12) as PlannedCount, " +
                    "CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs, " +
                    "CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount, PercentHrs,PercentCount " +
                    "from master_Summary_MW_Avg_Yearly2", con);
                cmd2.ExecuteNonQuery();


                string subQuer1 = "CREATE VIEW master_Summary_Turbine_Avg_Yearly_N AS select WEICan.System , CONVERT(DECIMAL(10,4),(isnull(WEICan.FTH,0)";
                string subQuer2 = "((select sum(TurbineCount) from WEICan_SubGroup)";
                string subQuer3 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.ForcedCount*1.0,0)";
                string subQuer4 = "((select sum(TurbineCount) from WEICan_SubGroup)";

                string subQuer5 = ", CONVERT(DECIMAL(10,4),(isnull(WEICan.MTH,0)";
                string subQuer6 = "((select sum(TurbineCount) from WEICan_SubGroup)";
                string subQuer7 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.MaintCount*1.0,0)";
                string subQuer8 = "((select sum(TurbineCount) from WEICan_SubGroup)";

                string subQuer9 = ", CONVERT(DECIMAL(10,4),(isnull(WEICan.PTH,0)";
                string subQuer10 = "((select sum(TurbineCount) from WEICan_SubGroup)";
                string subQuer11 = ",CONVERT(DECIMAL(10,4),(isnull(WEICan.PlannedCount*1.0,0)";
                string subQuer12 = "((select sum(TurbineCount) from WEICan_SubGroup)";

                //string subQuer13 = ", CONVERT(DECIMAL(10,5),(isnull(WEICan.FTH,0)";

                string subQuer20 = "from WEICan_Wind_Farm_Summary_Category WEICan  ";

                foreach (String Name in listp)
                {
                    if (Name != "WEICan")
                    {
                        subQuer1 += "+isnull(" + Name + ".FTH,0)";
                        subQuer2 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer3 += "+isnull(" + Name + ".ForcedCount*1.0,0)";
                        subQuer4 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";

                        subQuer5 += "+isnull(" + Name + ".MTH,0)";
                        subQuer6 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer7 += "+isnull(" + Name + ".MaintCount*1.0,0)";
                        subQuer8 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";

                        subQuer9 += "+isnull(" + Name + ".PTH,0)";
                        subQuer10 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";
                        subQuer11 += "+isnull(" + Name + ".PlannedCount*1.0,0)";
                        subQuer12 += "+(select sum(TurbineCount) from " + Name + "_SubGroup)";



                        subQuer20 += "full join " + Name + "_Wind_Farm_Summary_Category " + Name + " " +
                            "on WEICan.System = " + Name + ".System ";

                    }
                }
                subQuer1 += ")/";
                subQuer2 += ")) as FTH ";
                subQuer3 += ")/";
                subQuer4 += ")) as ForcedCount ";

                subQuer5 += ")/";
                subQuer6 += ")) as MTH ";
                subQuer7 += ")/";
                subQuer8 += ")) as MaintCount ";

                subQuer9 += ")/";
                subQuer10 += ")) as PTH ";
                subQuer11 += ")/";
                subQuer12 += ")) as PlannedCount ";

                string subQuer21 = subQuer1 + subQuer2 + subQuer3 + subQuer4 + subQuer5 + subQuer6 + subQuer7 + subQuer8 + subQuer9 + subQuer10 + subQuer11 + subQuer12 + subQuer20;
                // MessageBox.Show("query: " + subQuer21);
                SqlCommand cm0 = new SqlCommand(subQuer21, con);
                cm0.ExecuteNonQuery();

                SqlCommand cm = new SqlCommand("CREATE VIEW master_Summary_Turbine_Avg_Yearly2 AS " +
                    "select System, FTH, ForcedCount, MTH, MaintCount, PTH, PlannedCount, " +
                    "(FTH+MTH+PTH) AS TotalHrs, (ForcedCount+MaintCount+PlannedCount) AS TotalCount, " +
                    "CONVERT(DECIMAL(10,4),(FTH+MTH+PTH)*1.0/(select sum(FTH+MTH+PTH)*1.0 from master_Summary_Turbine_Avg_Yearly_N group by ())) as PercentHrs, " +
                    "CONVERT(DECIMAL(10,4),(ForcedCount+MaintCount+PlannedCount)*1.0/(select sum(ForcedCount+MaintCount+PlannedCount) from master_Summary_Turbine_Avg_Yearly_N group by ())) as PercentCount " +
                    "FROM master_Summary_Turbine_Avg_Yearly_N", con);
                cm.ExecuteNonQuery();


                SqlCommand cm2 = new SqlCommand("CREATE VIEW master_Summary_Turbine_Avg_Monthly AS " +
                    "select System, " +
                    "CONVERT(DECIMAL(10,4),FTH/12) as FTH, " +
                    "CONVERT(DECIMAL(10,4),ForcedCount/12) as ForcedCount, " +
                    "CONVERT(DECIMAL(10,4),MTH/12) as MTH, " +
                    "CONVERT(DECIMAL(10,4),MaintCount/12) as MaintCount, " +
                    "CONVERT(DECIMAL(10,4),PTH/12) as PTH, " +
                    "CONVERT(DECIMAL(10,4),PlannedCount/12) as PlannedCount, " +
                    "CONVERT(DECIMAL(10,5),TotalHrs/12) as TotalHrs, " +
                    "CONVERT(DECIMAL(10,5),TotalCount/12) as TotalCount, PercentHrs,PercentCount " +
                    "from master_Summary_Turbine_Avg_Yearly2", con);
                cm2.ExecuteNonQuery();


                

                MessageBox.Show("succeed");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }

        private void button13_Click(object sender, EventArgs e)//convert the 4 tables (old standard) to 3 tables (new standard) , choose the right attributes in order to generate 3 new tables and delete four old tables
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                string famName = textBox_farm.Text;
                string farm_outages = textBox_farm.Text + "_Outages";
                string farm_performance = textBox_farm.Text + "_Performance";
                string farm_SubGroup = textBox_farm.Text + "_SubGroup";

                SqlCommand cmd1 = new SqlCommand("select UtilityID  ,  PlantIDName  ,  GroupIDName  ,  SubGroupID  ,  " +
                    "ReptMonth  ,  ReptYear  ,SysCompCode  ," +
                    "FTH  ,ForcedCount  ,MTH  , MaintCount  ,PTH  ,  PlannedCount  ,  " +
                    "EFDTH ,  EMDTH , EPDTH , FXDTH , MXDTH , PXDTH " +
                    "into "+farm_outages+ " from "+ famName + "_Component", con);
                SqlDataReader myReader1 = cmd1.ExecuteReader();
                while (myReader1.Read()) { }
                myReader1.Close();

                SqlCommand cmd2 = new SqlCommand("select UtilityID  ,  PlantIDName  ,  GroupIDName  ,  SubGroupID  ,  " +
                    "ReptMonth  ,  ReptYear  ,  SGStatus  ,  " +
                    "GAG  ,  NAG  ,  NMC  ,  PDTH  ,  CTH  ,  RSTH  ,  " +
                    "FTH  ,  MTH  ,  PTH  ,  OFTH  ,  OMTH  ,  OPTH  ,  RUTH  ,  IRTH  ,  MBTH  ,  RTH  ,  " +
                    "EFDTH  ,  EMDTH  ,  EPDTH  ,  OEFDTH as OEFTH ,  OEMDTH as OEMTH, OEPDTH , ERSDTH , FXDTH , MXDTH , PXDTH "+
                    " into "+farm_performance+ " from "+famName + "_Plant_Performance", con);
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read()) { }
                myReader2.Close();

                SqlCommand cmd3 = new SqlCommand("select  [a].[UtilityID]         ,    [State] as Region            ," +
                    "    [a].PlantIDName       ,    [a].GroupIDName      ,    [SubGroupID]        ,    [SubGroupName]      ,    " +
                    "[ISOID]             ,    [Country]           ,    [NearCity]          ,    [State]             ,    " +
                    "[Latitude]         ,    [Longitude]         ,    [Elevation]     ,    [WRegime]          ,    " +
                    "[AAWS]              ,    [SCADAMfr]          ,    [SCADAMdl]          ,    " +
                    "[b].CommYear          ,    [TotInstCapacity]   ,    [RsrvCapacity]      ,    [TurbineCount]      ,    " +
                    "[SystemMW]          ,    [SystemMW] as MaxTurbineCap     ,    [TurbineMfr]        ,    " +
                    "[TurbineMdl]        ,    [TurbineMdlVer]     ,    [RotorHeight]       ,    " +
                    "[RotorDiam]         ,    [CutinSpd]          ,    [LowCutoutSpd]      ,    " +
                    "[HighCutoutSpd]     ,    [TurbIntensity]     ,    [AvgWind Spd] AvgWindSpd        ,    " +
                    "[WindShear]         ,    [ReferenceAnemom]  " +
                    "into "+farm_SubGroup+" from ["+famName+ "_Sub_Groups] a	" +
                    "inner join ["+famName+ "_Groups] b " +
                    "on a.PlantIDName = b.PlantIDName", con);
                SqlDataReader myReader3 = cmd3.ExecuteReader();
                while (myReader3.Read()) { }
                myReader3.Close();

                string Q51 = "drop table  " + famName + "_Component ";
                SqlCommand cmd51 = new SqlCommand(Q51, con);
                cmd51.ExecuteNonQuery();

                string Q61 = "drop table  "+famName + "_Plant_Performance ";
                SqlCommand cmd61 = new SqlCommand(Q61, con);
                cmd61.ExecuteNonQuery();
                string Q71 = "drop table " + famName + "_Sub_Groups ";
                SqlCommand cmd71 = new SqlCommand(Q71, con);
                cmd71.ExecuteNonQuery();

                string Q81 = "drop table " + famName + "_Groups ";
                SqlCommand cmd81 = new SqlCommand(Q81, con);
                cmd81.ExecuteNonQuery();


                MessageBox.Show("succeed");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void button14_Click(object sender, EventArgs e)//connect to database and define the 4 tables (Component, Plant_Performance, Sub_Groups, Groups) for old standard
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();

                string farm_outages = textBox_farm.Text + "_Component";
                string farm_performance = textBox_farm.Text + "_Plant_Performance";
                string farm_SubGroup = textBox_farm.Text + "_Sub_Groups";
                string farm_Groups = textBox_farm.Text + "_Groups";

                SqlCommand cmd1 = new SqlCommand("CREATE TABLE [dbo].[" + farm_outages + "] ( " +
                    "[PK]             INT           IDENTITY (1, 1) NOT NULL," +
       "  [PlantIDName]    NVARCHAR(50) NULL, " +
       " [GroupIDName]    NVARCHAR(50) NULL, " +
       " [SubGroupID]     NVARCHAR(50) NULL, " +
       " [UtilityID]      NCHAR(10)    NULL, " +
       " [NERC Unit Code] NCHAR(10)    NULL, " +
       " [ReptMonth]      INT           NULL, " +
       " [ReptYear]       INT           NULL, " +
       " [SysCompCode]    INT           NULL, " +
       " [FTH]            FLOAT(53)    NULL, " +
       " [ForcedCount]    INT           NULL, " +
       " [MTH]            FLOAT(53)    NULL, " +
       " [MaintCount]     INT           NULL, " +
       " [PTH]            FLOAT(53)    NULL, " +
       " [PlannedCount]   INT           NULL, " +
      "  [EFDTH]          FLOAT(53)    NULL, " +
       " [EMDTH]          FLOAT(53)    NULL, " +
        "[EPDTH]          FLOAT(53)    NULL, " +
        "[FXDTH]          FLOAT(53)    NULL, " +
        "[MXDTH]          FLOAT(53)    NULL, " +
        "[PXDTH]          FLOAT(53)    NULL, " +
                    "CONSTRAINT [PK_" + farm_outages + "] PRIMARY KEY CLUSTERED ([PK] ASC)) ", con);
                SqlDataReader myReader1 = cmd1.ExecuteReader();
                while (myReader1.Read()) { }
                myReader1.Close();

                SqlCommand cmd2 = new SqlCommand("CREATE TABLE [dbo].[" + farm_performance + "] ( " +
                    "[PK]          INT          IDENTITY (1, 1) NOT NULL, " +
                    "[PlantIDName]    NVARCHAR (50) NULL," +
        "[GroupIDName]    NVARCHAR(50) NULL, " +
        "[SubGroupID]     NVARCHAR(50) NULL, " +
        "[UtilityID]      NCHAR(10)    NULL, " +
        "[NERC Unit Code] NCHAR(10)    NULL, " +
        "[ReptMonth]      INT           NULL, " +
        "[ReptYear]       INT           NULL, " +
        "[SGStatus]       NCHAR(10)    NULL, " +
        "[GAG]            FLOAT(53)    NULL, " +
        "[NAG]            FLOAT(53)    NULL, " +
        "[NMC]            FLOAT(53)    NULL, " +
        "[PDTH]           FLOAT(53)    NULL, " +
        "[CTH]            FLOAT(53)    NULL, " +
        "[RSTH]           FLOAT(53)    NULL, " +
        "[FTH]            FLOAT(53)    NULL, " +
        "[MTH]            FLOAT(53)    NULL, " +
        "[PTH]            FLOAT(53)    NULL, " +
        "[OFTH]           FLOAT(53)    NULL, " +
        "[OMTH]           FLOAT(53)    NULL, " +
        "[OPTH]           FLOAT(53)    NULL, " +
        "[RUTH]           FLOAT(53)    NULL, " +
        "[IRTH]           FLOAT(53)    NULL, " +
        "[MBTH]           FLOAT(53)    NULL, " +
        "[RTH]            FLOAT(53)    NULL, " +
        "[EFDTH]          FLOAT(53)    NULL, " +
        "[EMDTH]          FLOAT(53)    NULL, " +
        "[EPDTH]          FLOAT(53)    NULL, " +
        "[OEFDTH]         FLOAT(53)    NULL, " +
        "[OEMDTH]         FLOAT(53)    NULL, " +
        "[OEPDTH]         FLOAT(53)    NULL, " +
        "[ERSDTH]         FLOAT(53)    NULL, " +
        "[FXDTH]          FLOAT(53)    NULL, " +
        "[MXDTH]          FLOAT(53)    NULL, " +
        "[PXDTH]          FLOAT(53)    NULL, " +
                    "CONSTRAINT [PK_" + farm_performance + "] PRIMARY KEY CLUSTERED ([PK] ASC))", con);
                SqlDataReader myReader2 = cmd2.ExecuteReader();
                while (myReader2.Read()) { }
                myReader2.Close();

                SqlCommand cmd3 = new SqlCommand("CREATE TABLE [dbo].[" + farm_SubGroup + "] (" +
                    "[PK]                INT          IDENTITY (1, 1) NOT NULL," +
                    "[PlantIDName]      NVARCHAR (50) NULL," +
        "[GroupIDName]      NVARCHAR(50) NULL, " +
        "[SubGroupID]       NVARCHAR(50) NULL, " +
        "[UtilityID]        NCHAR(10)    NULL, " +
        "[NERC Unit Code]   NCHAR(10)    NULL, " +
        "[Sub‐Group Number] INT           NULL, " +
        "[SubGroupName]     NVARCHAR(50) NULL, " +
        "[CommYear]         INT           NULL, " +
        "[SystemMW]         FLOAT(53)    NULL, " +
        "[TurbineCount]     INT           NULL, " +
        "[TurbineMfr]       NCHAR(10)    NULL, " +
        "[TurbineMdl]       NVARCHAR(50) NULL, " +
        "[TurbineMdlVer]    NVARCHAR(50) NULL, " +
        "[RotorHeight]      FLOAT(53)    NULL, " +
        "[RotorDiam]        FLOAT(53)    NULL, " +
        "[CutinSpd]         FLOAT(53)    NULL, " +
        "[LowCutoutSpd]     FLOAT(53)    NULL, " +
        "[HighCutoutSpd]    FLOAT(53)    NULL, " +
        "[TurbIntensity]    INT           NULL, " +
        "[AvgWind Spd]      FLOAT(53)    NULL, " +
        "[WindShear]        INT           NULL, " +
        "[ReferenceAnemom]  INT           NULL, " +

                    "CONSTRAINT [PK_" + farm_SubGroup + "] PRIMARY KEY CLUSTERED ([PK] ASC))", con);
                SqlDataReader myReader3 = cmd3.ExecuteReader();
                while (myReader3.Read()) { }
                myReader3.Close();

                SqlCommand cmd4 = new SqlCommand("CREATE TABLE [dbo].[" + farm_Groups + "] (" +
                    "[PK]                INT          IDENTITY (1, 1) NOT NULL," +
                    "[PlantIDName]              NVARCHAR (50) NULL," +
        "[GroupIDName]              NVARCHAR(50) NULL, " +
        "[Turbine Group Name]       NVARCHAR(50) NULL, " +
        "[UtilityID]                NCHAR(10)    NULL, " +
        "[NERC Unit Code]           NCHAR(10)    NULL, " +
        "[ISOID]                    NVARCHAR(50) NULL, " +
        "[TotInstCapacity]          FLOAT(53)    NULL, " +
        "[RsrvCapacity]             FLOAT(53)    NULL, " +
        "[CommYear]                 INT           NULL, " +
        "[Country]                  NCHAR(10)    NULL, " +
        "[NearCity]                 NVARCHAR(50) NULL, " +
        "[State]                    NCHAR(10)    NULL, " +
        "[Longitude]                FLOAT(53)    NULL, " +
        "[Latitude]                 FLOAT(53)    NULL, " +
        "[Elevation]                FLOAT(53)    NULL, " +
        "[WRegime]                  INT           NULL, " +
        "[AAWS]                     FLOAT(53)    NULL, " +
        "[Left Blank Intentionally] NCHAR(10)    NULL, " +
        "[SCADAMfr]                 NCHAR(10)    NULL, " +
        "[SCADAMdl]                 NCHAR(10)    NULL, " +

                    "CONSTRAINT [PK_" + farm_Groups + "] PRIMARY KEY CLUSTERED ([PK] ASC))", con);
                SqlDataReader myReader4 = cmd4.ExecuteReader();
                while (myReader4.Read()) { }
                myReader4.Close();

                MessageBox.Show("succeed");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {


                DataSet dataSet2 = new DataSet();
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from " + textBox_sheet2.Text, con);


                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                sda.Fill(dataSet2);
                //dataGridView1.DataSource = dataSet2.Tables[0];


                //builder.GetInsertCommand();
                int totalCol = dataSet2.Tables[0].Columns.Count;
                int totalRow = dataSet2.Tables[0].Rows.Count;

                for (int count = 0; count < list1.Count; count++)
                {

                    foreach (DataRow r in dataset3.Tables[count].Rows)
                    {
                       

                        for (int a = 1; a < dataset3.Tables[count].Columns.Count + 1; a++)
                        {
                            if (a == 7)
                            {
                                r[a - 1].ToString().Split('-').Last();
                                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT Entry FROM [Sys-Com Codes] where Component like '%" + r[a - 1].ToString().Split('-').Last() + "' ", con);
                                System.Data.DataTable dtp = new System.Data.DataTable();
                                myDataAdapterp.Fill(dtp);
                                List<String> listp = new List<string>();
                                foreach (DataRow row in dtp.Rows)
                                {
                                    listp.Add(row[0].ToString());

                                }

                                if (listp.Count() == 1)
                                {
                                    r[a - 1] = listp.First();
                                }
                            }
                        }

                        
                        
                    }
                }

                /*for (int count = 0; count < list1.Count; count++)
                {

                    foreach (DataRow r in dataset3.Tables[count].Rows)
                    {
                        DataRow dr = dataSet2.Tables[0].NewRow();

                        for (int a = 1; a < dataset3.Tables[count].Columns.Count + 1; a++)
                        {
                            if (a == 7)
                            {
                                


                                if (r[a - 1].ToString() == "BOP-Breakers")
                                {
                                    r[a - 1] = "1037";
                                }
                                if (r[a - 1].ToString() == "BOP-Preventative Maintenance")
                                {
                                    r[a - 1] = "682";
                                }
                                if (r[a - 1].ToString() == "BOP-Overhead Lines")
                                {
                                    r[a - 1] = "652";
                                }
                                if (r[a - 1].ToString() == "BOP-Underground")
                                {
                                    r[a - 1] = "650";
                                }
                                if (r[a - 1].ToString() == "Brake-High Speed Shaft Brake")
                                {
                                    r[a - 1] = "617";
                                }
                                if (r[a - 1].ToString() == "CS-Cabinet Cooling/Heating")
                                {
                                    r[a - 1] = "648";
                                }
                                if (r[a - 1].ToString() == "CS-General")
                                {
                                    r[a - 1] = "672";
                                }
                                if (r[a - 1].ToString() == "CS-Hardware")
                                {
                                    r[a - 1] = "1046";
                                }
                                if (r[a - 1].ToString() == "CS-Processor")
                                {
                                    r[a - 1] = "645";
                                }
                                if (r[a - 1].ToString() == "CS-Sensors")
                                {
                                    r[a - 1] = "642";
                                }
                                if (r[a - 1].ToString() == "CS-Wind Vane and Anemometer")
                                {
                                    r[a - 1] = "649";
                                }
                                if (r[a - 1].ToString() == "DT-Main Bearings")
                                {
                                    r[a - 1] = "613";
                                }
                                if (r[a - 1].ToString() == "Elec-Circuit Breakers and Switches")
                                {
                                    r[a - 1] = "661";
                                }
                                if (r[a - 1].ToString() == "Elec-Power Converters")
                                {
                                    r[a - 1] = "658";
                                }
                                if (r[a - 1].ToString() == "Elec-Power Supply")
                                {
                                    r[a - 1] = "1053";
                                }
                                if (r[a - 1].ToString() == "GB-Gear Box Heating/Cooling")
                                {
                                    r[a - 1] = "609";
                                }
                                if (r[a - 1].ToString() == "GB-Gear Box Oil System")
                                {
                                    r[a - 1] = "610";
                                }
                                if (r[a - 1].ToString() == "GB-General")
                                {
                                    r[a - 1] = "669";
                                }
                                if (r[a - 1].ToString() == "Gen-General")
                                {
                                    r[a - 1] = "668";
                                }

                                if (r[a - 1].ToString() == "Gen-Generator Bearings")
                                {
                                    r[a - 1] = "632";
                                }
                                if (r[a - 1].ToString() == "Gen-Generator Cooling Systems")
                                {
                                    r[a - 1] = "636";
                                }
                                if (r[a - 1].ToString() == "Gen-Power Slip Rings")
                                {
                                    r[a - 1] = "1059";
                                }
                                if (r[a - 1].ToString() == "Gen-RCC (Rotor Current Control)")
                                {
                                    r[a - 1] = "641";
                                }
                                if (r[a - 1].ToString() == "Pitch-Battery Backup")
                                {
                                    r[a - 1] = "1061";
                                }
                                if (r[a - 1].ToString() == "Pitch-Electrical")
                                {
                                    r[a - 1] = "626";
                                }
                                if (r[a - 1].ToString() == "Pitch-Mechanical")
                                {
                                    r[a - 1] = "624";
                                }
                                if (r[a - 1].ToString() == "Pitch-Pitch Controller")
                                {
                                    r[a - 1] = "1062";
                                }
                                if (r[a - 1].ToString() == "Pitch-Pitch Hydraulics")
                                {
                                    r[a - 1] = "625";
                                }
                                if (r[a - 1].ToString() == "Pitch-Pitch Motor")
                                {
                                    r[a - 1] = "1063";
                                }
                                if (r[a - 1].ToString() == "Rotor-Blades")
                                {
                                    r[a - 1] = "600";
                                }
                                if (r[a - 1].ToString() == "Rotor-General")
                                {
                                    r[a - 1] = "665";
                                }
                                if (r[a - 1].ToString() == "Struct-Foundations")
                                {
                                    r[a - 1] = "595";
                                }
                                if (r[a - 1].ToString() == "Struct-Towers")
                                {
                                    r[a - 1] = "594";
                                }
                                if (r[a - 1].ToString() == "WTG-General")
                                {
                                    r[a - 1] = "1032";
                                }
                                if (r[a - 1].ToString() == "WTG-Preventative Maintenance")
                                {
                                    r[a - 1] = "1031";
                                }
                                if (r[a - 1].ToString() == "Yaw-General")
                                {
                                    r[a - 1] = "663";
                                }
                            }
                            if (r[a - 1].ToString() == null)
                            {
                                r[a - 1] = "0";
                            }
                            if (r[a - 1].ToString() == "N/A")
                            {
                                r[a - 1] = "0";
                            }

                            dr[a] = r[a - 1];
                        }

                        dataSet2.Tables[0].Rows.Add(dr);
                        //builder.GetInsertCommand();
                    }
                }*/


                /*sda.UpdateCommand = builder.GetUpdateCommand();
                sda.Update(dataSet2);
                //fList2.Add(new System.IO.FileInfo(textBox_path2.Text));
                dataGridView1.DataSource = dataSet2.Tables[0];*/
                MessageBox.Show("conversion sys-com codes succeed");




                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sorry for the complex process");
        }

        private void label7_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                //label7 = config.AppSettings.Settings["connectionString"].Value.ToString();
                string value = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
                label7.Text = value;
                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Performance'", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString().Split('_')[0]);

                }
                comboBox3.DataSource = listp;
                label2.Text = listp.Count() + "";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void textBox_farm_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["connectionString"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = connectionString;
                con.Open();
                System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                //label7 = config.AppSettings.Settings["connectionString"].Value.ToString();
                string value = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
                string value2 = value.Split('=')[2];
                string value3 = value2.Split(';')[0];
                label7.Text = value3;
                SqlDataAdapter myDataAdapterp = new SqlDataAdapter("SELECT name FROM sys.Tables where name like '%_Performance'", con);
                System.Data.DataTable dtp = new System.Data.DataTable();
                myDataAdapterp.Fill(dtp);
                List<String> listp = new List<string>();
                foreach (DataRow row in dtp.Rows)
                {
                    listp.Add(row[0].ToString().Split('_')[0]);

                }
                comboBox3.DataSource = listp;
                label2.Text = listp.Count() + "";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void textBox_sheet2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
